module.exports = {
    packages: { 
        'ngx-swiper-wrapper': {
            ignorableDeepImportMatchers: [
              /swiper\//,
            ]
        }
    }
};
/* SystemJS module definition */
declare var module: NodeModule;
declare var jQuery: any;
declare var $: any;
declare var ENV: string;

interface NodeModule {
  id: string;
}
declare module 'quill';
declare module 'leaflet';
declare module 'perfect-scrollbar';
declare module 'screenfull';
declare module 'd3-shape';

import { NavbarComponent } from './navbar/navbar.component';
import { CustomizerComponent } from './customizer/customizer.component';
import { SidebarComponent } from './sidebar/sidebar.component';
import { NotificationSidebarComponent } from './notification-sidebar/notification-sidebar.component';
import { FooterComponent } from './footer/footer.component';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';

import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { TranslateModule } from '@ngx-translate/core';

import { ToggleFullscreenDirective } from './directives/toggle-fullscreen.directive';
import { FormsModule } from '@angular/forms';
import { UiSwitchModule } from 'ngx-ui-switch';
import { Ng2PaginationModule } from 'ng2-pagination';
import { NgbdModalRemoveComponent } from './modals/modals-remove.component';
import { NgbdModalConfirmComponent } from './modals/modals-confirm.component';
import { NgbdModalInfoComponent } from './modals/modals-info.component';

@NgModule({
    imports: [
        RouterModule,
        CommonModule,
        NgbModule,
        TranslateModule,
        FormsModule,
        Ng2PaginationModule,
        UiSwitchModule
    ],
    exports: [
        CommonModule,
        FooterComponent,
        NavbarComponent,
        SidebarComponent,
        CustomizerComponent,
        NotificationSidebarComponent,
        ToggleFullscreenDirective,
        NgbModule,
        TranslateModule,
        FormsModule,
        Ng2PaginationModule,
        UiSwitchModule
    ],
    declarations: [
        FooterComponent,
        NavbarComponent,
        SidebarComponent,
        CustomizerComponent,
        NotificationSidebarComponent,
        ToggleFullscreenDirective,
        NgbdModalRemoveComponent,
        NgbdModalConfirmComponent,
        NgbdModalInfoComponent
    ],
    entryComponents: [
        NgbdModalRemoveComponent,
        NgbdModalConfirmComponent,
        NgbdModalInfoComponent]
})

export class SharedModule { }

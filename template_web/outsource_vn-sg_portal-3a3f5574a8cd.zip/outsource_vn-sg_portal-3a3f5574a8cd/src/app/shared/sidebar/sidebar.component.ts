import { GlobalState } from './../../global.state';
import { UserIdentityService } from './../../services/user-identity.service';
import { MetaService } from '@ngx-meta/core';
import { ToastrService } from 'ngx-toastr';
import { BaseComponent } from './../../components/base.component';
import { Component, OnInit } from '@angular/core';
import { ROUTES } from './sidebar-routes.config';
import { Router, ActivatedRoute } from '@angular/router';
import { AVATAR_DEFAULT, STATE_EVENT } from './../../modules/constants';
import { Location } from '@angular/common';
import { RouteInfo } from './sidebar.metadata';

declare var $: any;

@Component({
    selector: 'app-sidebar',
    templateUrl: './sidebar.component.html',
})

export class SidebarComponent extends BaseComponent implements OnInit {
    public menuItems: any[];
    public AVATAR_DEFAULT = AVATAR_DEFAULT;
    public profileMenu = UserIdentityService.getProfile();
    // constructor(private router: Router,
    //     private route: ActivatedRoute, public translate: TranslateService) {
    // }

    constructor(
        public _router: Router,
        public _route: ActivatedRoute,
        public _meta: MetaService,
        public _location: Location,
        public _toastr: ToastrService,
        private _state: GlobalState
    ) {
        super(_router, _route, _meta, _location, _toastr);
        // listen event update profile
        this._state.subscribe(STATE_EVENT.UPDATE_PROFILE, (user) => {
            this.profileMenu = user;
        });
    }

    ngOnInit() {
        $.getScript('./assets/js/app-sidebar.js');
        this.menuItems = ROUTES.filter(menuItem => menuItem);
    }

    // NGX Wizard - skip url change
    ngxWizardFunction(path: string) {
        if (path.indexOf('forms/ngx') !== -1)
            this._router.navigate(['forms/ngx/wizard'], { skipLocationChange: false });
    }

    /**
     * Verify permission access function on portal.
     * @param menuItem
     */
    public verifyPrivileges(menuItem: RouteInfo): boolean {
        let isValid = false;

        if (this.profile && this.profile.roleId) {
            if (menuItem && menuItem.privileges && menuItem.privileges.indexOf(this.profile.roleId) !== -1) {
                isValid = true;
            }
        }

        return isValid;
    }
}

import { RouteInfo } from './sidebar.metadata';
import { ROLE } from 'app/modules';

// Sidebar menu Routes and data
export const ROUTES: RouteInfo[] = [
    {
        path: '/dashboard',
        title: 'Dashboard',
        icon: 'ft-home',
        class: '',
        badge: '',
        badgeClass: '',
        isExternalLink: false,
        submenu: [],
        privileges: [ROLE.SYSTEM_ADMIN, ROLE.MANAGER]
    },
    {
        path: '/users',
        title: 'Users',
        icon: 'ft-users',
        class: '',
        badge: '',
        badgeClass: '',
        isExternalLink: false,
        submenu: [],
        privileges: [ROLE.SYSTEM_ADMIN, ROLE.MANAGER]
    },
    {
        path: '/notification_messages',
        title: 'Notifications',
        icon: 'ft-message-square',
        class: '',
        badge: '',
        badgeClass: '',
        isExternalLink: false,
        submenu: [],
        privileges: [ROLE.SYSTEM_ADMIN, ROLE.MANAGER]
    },
    {
        path: '/settings',
        title: 'Tasks',
        icon: 'ft-layers',
        class: '',
        badge: '',
        badgeClass: '',
        isExternalLink: false,
        submenu: [],
        privileges: [ROLE.SYSTEM_ADMIN, ROLE.MANAGER]
    }
];

import { Component, Input } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'ngbd-modal-content',
  template: `
    <div class="modal-header">
      <h3 class="modal-title text-primary text-bold-600">{{title}}</h3>
      <button type="button" class="close" aria-label="Close" (click)="activeModal.dismiss('cross')">
        <span aria-hidden="true">&times;</span>
      </button>
    </div>
    <div class="modal-body">
      <p *ngIf="content != ''">{{content}}</p>
      <p *ngIf="contentHTML != ''" [innerHTML]="contentHTML"></p>
    </div>
    <div class="modal-footer">
      <button type="button" class="btn btn-raised btn-secondary" (click)="activeModal.close('Close')"><i class="ft-x"></i> {{'Close' | translate}}</button>
    </div>
  `
})

export class NgbdModalInfoComponent {
  @Input() title;
  @Input() content;
  @Input() contentHTML;

  constructor(public activeModal: NgbActiveModal) { }
}
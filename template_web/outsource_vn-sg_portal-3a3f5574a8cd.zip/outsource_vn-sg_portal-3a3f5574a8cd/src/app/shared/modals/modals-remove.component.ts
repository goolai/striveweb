import { Component, Input } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'ngbd-modal-content',
  template: `
    <div class="modal-header">
      <h3 class="modal-title text-danger text-bold-600">{{title}}</h3>
      <button type="button" class="close" aria-label="Close" (click)="activeModal.dismiss('cross')">
        <span aria-hidden="true">&times;</span>
      </button>
    </div>
    <div class="modal-body">
      <p>{{content}}</p>
    </div>
    <div class="modal-footer">
      <button type="button" class="btn btn-raised btn-danger" (click)="activeModal.close('Delete')"><i class="ft-trash-2"></i> {{'Delete' | translate}}</button>
      <button type="button" class="btn btn-raised btn-secondary" (click)="activeModal.close('Cancel')"><i class="ft-x"></i> {{'Cancel' | translate}}</button>
    </div>
  `
})

export class NgbdModalRemoveComponent {
  @Input() title;
  @Input() content;

  constructor(public activeModal: NgbActiveModal) { }
}
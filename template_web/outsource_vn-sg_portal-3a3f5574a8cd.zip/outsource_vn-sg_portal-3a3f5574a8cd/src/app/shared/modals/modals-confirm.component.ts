import { Component, Input } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'ngbd-modal-content',
  template: `
    <div class="modal-header">
      <h3 class="modal-title text-warning text-bold-600">{{title}}</h3>
      <button type="button" class="close" aria-label="Close" (click)="activeModal.dismiss('Cross')">
        <span aria-hidden="true">&times;</span>
      </button>
    </div>
    <div class="modal-body">
      <p>{{content}}</p>
    </div>
    <div class="modal-footer">
      <button type="button" class="btn btn-raised btn-warning" (click)="activeModal.close('OK')"><i class="ft-check"></i> {{'OK' | translate}}</button>
      <button type="button" class="btn btn-raised btn-secondary" (click)="activeModal.close()"><i class="ft-x"></i> {{'Cancel' | translate}}</button>
    </div>
  `
})

export class NgbdModalConfirmComponent {
  @Input() title;
  @Input() content;

  constructor(public activeModal: NgbActiveModal) { }
}
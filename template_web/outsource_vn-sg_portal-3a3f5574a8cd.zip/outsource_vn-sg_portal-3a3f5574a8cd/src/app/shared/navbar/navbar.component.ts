import { Component, ViewEncapsulation, OnInit } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { AuthService, UserIdentityService } from '../../services';
import { BaseComponent } from '../../components/base.component';
import { Router, ActivatedRoute } from '@angular/router';
import { MetaService } from '@ngx-meta/core';
import { Location } from '@angular/common';
import { ToastrService } from 'ngx-toastr';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { NgbdModalConfirmComponent } from '../modals/modals-confirm.component';
import { SESSION } from 'app/modules';
import { ConfigService } from '@ngx-config/core';

@Component({
    selector: 'app-navbar',
    templateUrl: './navbar.component.html',
    styleUrls: ['./navbar.component.scss'],
    providers: [AuthService],
    encapsulation: ViewEncapsulation.None,
})

export class NavbarComponent extends BaseComponent implements OnInit {
    currentLang = 'en';
    toggleClass = 'ft-maximize';
    placement = 'bottom-right';
    public isCollapsed = true;
    public languages: any;

    constructor(
        public _router: Router,
        public _route: ActivatedRoute,
        public _meta: MetaService,
        public _location: Location,
        public _toastr: ToastrService,
        public _translate: TranslateService,
        public _authService: AuthService,
        public _modalService: NgbModal,
        protected _config: ConfigService
    ) {
        super(_router, _route, _meta, _location, _toastr);
    }

    public ngOnInit(): any {
        this.languages = this._config.getSettings('i18n.availableLanguages');
    }

    public ChangeLanguage(language: any) {
        this._translate.use(language.code).subscribe(() => {
            this._meta.setTag('og:locale', language.culture);

            sessionStorage.setItem(SESSION.LANGUAGE_KEYWORD, JSON.stringify(language));
            this.currentLanguage = language;
        });
    }

    public ToggleClass() {
        if (this.toggleClass === 'ft-maximize') {
            this.toggleClass = 'ft-minimize';
        } else {
            this.toggleClass = 'ft-maximize';
        }
    }

    /**
     * Logout
     */
    public logout() {
        try {
            const modalRef = this._modalService.open(NgbdModalConfirmComponent);

            modalRef.componentInstance.title = this._t('Logout');
            modalRef.componentInstance.content = this._t('Are you sure you want to logout?');

            modalRef.result.then(result => {
                if (result === 'OK') {
                    this._authService.logout()
                        .then((response) => {
                            if (response) {
                                this.setSuccess(response.message);
                                UserIdentityService.clearCredentials();
                                this.navigate(['login']);
                            }
                        })
                        .catch(error => {
                            this.setError(error);
                        });
                }
            }, (reason) => {
            });
        } catch (error) {
            this.setError(error);
        }
    }
}

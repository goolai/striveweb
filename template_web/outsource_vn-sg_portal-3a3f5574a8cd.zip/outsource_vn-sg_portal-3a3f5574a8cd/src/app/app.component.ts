import { Component, OnInit } from '@angular/core';
import { MetaService } from '@ngx-meta/core';
import { SESSION } from './modules/constants';
import { TranslateService } from '@ngx-translate/core';
import { ConfigService } from '@ngx-config/core';
import { PlatformHelper } from './helpers';

@Component({
    selector: 'app-root',
    templateUrl: './app.component.html'
})

export class AppComponent implements OnInit {
    constructor(
        private config: ConfigService,
        private meta: MetaService,
        private translate: TranslateService
    ) {
        this.setupSessionStorage();
    }

    ngOnInit() {
        this.setMetaData();
    }

    public setMetaData() {
        let defaultLanguage = this.config.getSettings('i18n.defaultLanguage');
        const defaultTitle = this.config.getSettings('seo.defaultPageTitle');
        const defaultMetaDescription = this.config.getSettings('seo.defaultMetaDescription');
        const currentLanguage = sessionStorage.getItem(SESSION.LANGUAGE_KEYWORD);

        defaultLanguage = currentLanguage ? JSON.parse(currentLanguage) : defaultLanguage;

        // add available languages & set default language
        this.translate.addLangs(this.config.getSettings('i18n.availableLanguages')
            .map((language: any) => language.code));
        this.translate.setDefaultLang(defaultLanguage.code);
        this.meta.setTag('og:locale', defaultLanguage.culture);
        this.meta.setTag('description', defaultMetaDescription);

        this.meta.setTitle(defaultTitle);
        this.setLanguage(defaultLanguage);
    }

    /**
     * Set language default.
     * @param language
     */
    private setLanguage(language: any): any {
        this.translate.use(language.code).subscribe(() => {
            this.meta.setTag('og:locale', language.culture);
            // sessionStorage.setItem(SESSION.LANGUAGE_KEYWORD, JSON.stringify(language));
        });
    }

    /**
     * Setup session storage.
     */
    public setupSessionStorage() {
        if (PlatformHelper.isPlatformBrowser()) {
            if (!sessionStorage.length) {
                // Ask other tabs for session storage
                localStorage.setItem('getSessionStorage', Date.now().toString());
            }

            window.addEventListener('storage', function (event) {
                if (event.key === 'getSessionStorage') {
                    // Some tab asked for the sessionStorage -> send it
                    localStorage.setItem('sessionStorage', JSON.stringify(sessionStorage));
                    localStorage.removeItem('sessionStorage');
                } else if (event.key === 'sessionStorage' && !sessionStorage.length) {
                    // sessionStorage is empty -> fill it
                    let data = JSON.parse(event.newValue);

                    for (let key in data) {
                        if (data[key]) {
                            sessionStorage.setItem(key, data[key]);
                        }
                    }
                }
            });
        }
    }
}

import { GlobalState } from './global.state';

export const APP_PROVIDERS = [
  GlobalState
];

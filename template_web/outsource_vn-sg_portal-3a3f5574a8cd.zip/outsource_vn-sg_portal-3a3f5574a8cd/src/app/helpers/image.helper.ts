import { IMAGE_ORIENTATION, MAX_SIZE_UPLOAD, MAX_MEDIA_SIZE_UPLOAD } from '../modules/constants';

export class ImageHelper {
  constructor() { }
  /**
   * Get Image
   * @param imageUrl
   * @param width
   * @param height
   * @param mode
   */
  public static getImage(imageUrl: string, option: any = {}) {
    return `${imageUrl}?width=${option.width}&height=${option.height}&quality=${option.quality}&mode=${option.mode}`;
  }

  /**
   *
   * @param width
   * @param height
   */
  public static getOrientation(width: number, height: number) {
    return width > height ? IMAGE_ORIENTATION.LANDSCAPE : IMAGE_ORIENTATION.PORTRAIT;
  }

  /**
   * Check is image
   * @param type
   */
  public static isValidImage(type: string) {
    const imageTypes = ['image/gif', 'image/jpeg', 'image/png'];
    return imageTypes.indexOf(type) < 0 ? false : true;
  }

  /**
   * Validate media file
   * @param type
   */
  public static isValidMediaFile(type: string) {
    const imageTypes = ['image/gif', 'image/jpeg', 'image/png', 'video/mp4'];
    return imageTypes.indexOf(type) < 0 ? false : true;
  }

  /**
   * Validate data file
   * @param type
   */
  public static isValidDataFile(type: string) {
    const imageTypes = ['.csv', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'application/vnd.ms-excel'];
    return imageTypes.indexOf(type) < 0 ? false : true;
  }

  /**
   * check file size
   * @param size
   */
  public static isValidFileSize(imageSize: number) {
    const maxSize = MAX_SIZE_UPLOAD * 1024 * 1024 ;
    return maxSize < imageSize ? false : true;
  }

  /**
   * Validate media file size
   * @param mediaSize
   */
  public static isValidMediaFileSize(mediaSize: number) {
    const maxSize = MAX_MEDIA_SIZE_UPLOAD * 1024 * 1024;
    return maxSize < mediaSize ? false : true;
  }
}

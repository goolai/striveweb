import * as PHE from 'print-html-element';
import { PlatformHelper } from './platform.helper';

export class PrintHelper {

    public printMode: string;
    public pageTitle: string;
    public templateString: string;
    public popupProperties: string = 'toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=no, resizable=no, copyhistory=no';
    public stylesheets: string | string[];
    public styles: string | string[];

    constructor() {
    }

    /**
     * Print By Element Id
     * @param elementId
     */
    public printByElementId(elementId: string = 'printContent') {
        if (PlatformHelper.isPlatformBrowser()) {
            // PHE.printElement(document.getElementById(elementId), this.getOptions());
            this.popupWindowPrint(document.getElementById(elementId).innerHTML);
        }
    }

    /**
     * Print Html
     * @param htmlContent
     */
    public printHtml(htmlContent: string) {
        if (PlatformHelper.isPlatformBrowser()) {
            // PHE.printHtml(htmlContent, this.getOptions());
            this.popupWindowPrint(htmlContent);
        }
    }

    /**
     * Print Options
     * @returns  {}
     */
    public getOptions() {
        return {
            printMode: this.printMode,
            pageTitle: this.pageTitle,
            templateString: this.templateString,
            popupProperties: this.popupProperties,
            stylesheets: this.stylesheets,
            styles: this.styles,
        };
    }

    /**
     * Custom print dialog.
     * @param content
     */
    private popupWindowPrint(content: string) {
        let popupWin = window.open('src', '_blank',
            'toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=no, resizable=no, copyhistory=no');
        // let popupWin = window.open('about:blank', 'printElementWindow');
        popupWin.window.focus();
        popupWin.document.open();
        popupWin.document.write(`<html><head></head><body onload="window.print();window.close()"><div>${content}</div></body></html>`);
        popupWin.document.close();
    }
}

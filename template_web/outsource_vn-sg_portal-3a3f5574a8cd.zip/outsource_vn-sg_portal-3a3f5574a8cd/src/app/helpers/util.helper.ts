import { SESSION, LANGUAGE } from '../modules/constants';
import * as _ from 'lodash';
import * as stringFormat from 'string-format';

export class UtilHelper {
  constructor() {

  }

  /**
   * Set Default Data
   * @param data
   * @returns {string}
   */
  public static setDataDefault(data, defaultValue: any = '') {
    const ret = data ? data : ((defaultValue !== '') ? defaultValue : '');

    return ret;
  }

  /**
   * Parse
   * @param data
   * @returns {string}
   */
  public static parseFilterToString(data) {
    let str = '';
    if (data) {
      _.forEach(data, function (item, key) {
        if (typeof item !== 'object' && item !== '' && item != null) {
          str += key + '=' + item + '&';
        }
      });
    }

    return str.substring(0, str.length - 1);
  }

  /**
   * Get string value.
   * @param val
   * @param defaultVal
   */
  public static getString(val: any, defaultVal?: string): string {
    return (val != null && _.isString(val) && val !== '') ? val : defaultVal != null ? defaultVal : undefined;
  }

  /**
   * Get array string
   * @param val
   * @param defaultVal
   */
  public static getArrayString(val: string[], defaultVal?: string[]): string[] {
    return (val != null && _.isArray(val)) ? val : defaultVal != null ? defaultVal : undefined;
  }

  /**
   * Get boolean value
   * @param val
   * @param defaultVal
   */
  public static getBoolean(val: any, defaultVal?: boolean): boolean {
    if (val != null) {
      if (typeof (val) === 'string') {
        val = val.toLowerCase();
      }
      switch (val) {
        case true:
        case 1:
        case 'yes':
        case 'right':
        case 'true':
        case '1':
          return true;
        default:
          return false;
      }
    }
    return defaultVal;
  }

  /**
   * Get number
   * @param val
   * @param defaultVal
   */
  public static getNumber(val: any, defaultVal: number = 0): number {
    if (val != null) {
      let num = Number(val);
      return isNaN(val) ? defaultVal : num;
    }
    return defaultVal;
  }

  /**
   * Parse
   * @param data
   * @returns {string}
   */
  public static parseFilterToStringNoEmpty(data) {
    let str = '';
    if (data) {
      _.forEach(data, function (item, key) {
        if (typeof item !== 'object' && item !== '') {
          str += key + '=' + item + '&';
        }
      });
    }

    return str.substring(0, str.length - 1);
  }

  /**
   * Parse
   * @param str
   * @returns {object}
   */
  public static parseQueryStringToObject(str) {
    const vars = str.split('&');
    const result = {};

    for (let i = 0; i < vars.length; i++) {
      const pair = vars[i].split('=');
      result[pair[0]] = pair[1];
    }

    return result;
  }

  /**
   *
   * @param array
   * @param attribute
   * @param value
   * @returns {any}
   */
  public static findByAttribute(array, attribute, value) {
    return _.find(array, function (item) {
      return item[attribute] === value;
    });
  }

  /**
   *
   * @param array
   * @param attribute
   * @param value
   * @returns {Array}
   */
  public static findAllByAttribute(array, attribute, value) {
    const result = [];
    _.forEach(array, function (item) {
      if (item[attribute] === value) {
        result.push(item);
      }
    });

    return result;
  }

  /**
   *
   * @param message
   * @param params
   */
  public static translate(message: string, ...params: any[]): string {
    let language: any = sessionStorage.getItem(SESSION.LANGUAGE_KEYWORD);

    let ret: string = message;

    let data = require('../../assets/i18n/en.json');
    if (language) {
      language = JSON.parse(language);
      if (language.code !== LANGUAGE.ENGLISH) {
        data = require('../../assets/i18n/' + language.code + '.json');
      }
    }
    if (data[message]) {
      ret = data[message];
    }

    if (_.isArray(params)) {
      ret = stringFormat(ret, params);
    } else if (_.isString(ret) || _.isObject(params)) {
      ret = stringFormat(ret, params);
    }

    return ret;
  }

  /**
   * Use to slice long string
   * @param desc
   * @returns {string}
   */
  public static sliceText(text: string, maxLength: number) {
    if (text.length > maxLength) {
      return text.slice(0, maxLength) + '...';
    }

    return text;
  }
}

import * as _ from 'lodash';

export class StringHelper {
  constructor() {

  }

  /**
   * Parse
   * @param
   * @returns {string}
   */
  public static cutString(string, number) {
    const cutString = string.indexOf(' ', number);
    if (cutString === -1) {
      return string;
    }
    return string.substring(0, cutString);
  }

  /**
   *
   * @param str
   * @returns {string}
   */
  public static trim(str: string) {
    const lines = str.split('\n');
    let temp = '';
    for (let i = 0; i < lines.length; i++) {
      if (lines[i]) {
        temp += lines[i] + '\n';
      }
    }
    return temp.trim();
  }

}

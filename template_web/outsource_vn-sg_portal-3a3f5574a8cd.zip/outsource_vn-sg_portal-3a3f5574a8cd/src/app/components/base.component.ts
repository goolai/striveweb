import { UserIdentityService } from './../services';
import { Router, ActivatedRoute } from '@angular/router';
import { PAGINATION, SESSION, SORT_TYPES } from '../modules/constants';
import { UtilHelper } from '../helpers/util.helper';
import { UserModel } from '../models';
import { MetaService } from '@ngx-meta/core';
import { Location } from '@angular/common';
import * as _ from 'lodash';
import { ROLE, TOASTR_TIMEOUT } from '../modules/constants';
import { ToastrService } from 'ngx-toastr';

export class BaseComponent {
  public profile: UserModel;
  public pageTitle = '';
  public totalItems: number = 0;
  public currentPage: number = 1;
  public maxSize: number = PAGINATION.MAX_SIZE;
  public itemsPerPage: number = PAGINATION.ITEMS_PER_PAGE;
  public pageSizes = PAGINATION.PAGE_ITEM_SIZE;

  public selectedId = [];
  public bulkAll: boolean = false;

  public search: any;
  public isShowPassword: boolean = false;
  public isShowPasswordAgain: boolean = false;
  public isShowOldPassword: boolean = false;
  public currentLocation: string = '';
  public currentLanguage: any;
  public isASC: boolean = false;

  constructor(
    protected _router: Router,
    protected _route: ActivatedRoute,
    protected _meta: MetaService,
    protected _location: Location,
    protected _toastr: ToastrService
  ) {
    this.currentLocation = this._router.url;
    let currentLanguage: any = sessionStorage.getItem(SESSION.LANGUAGE_KEYWORD);
    this.profile = UserIdentityService.getProfile();

    if (this.profile == null) {
      this.profile = new UserModel();
    }

    if (currentLanguage) {
      currentLanguage = JSON.parse(currentLanguage);
      this.currentLanguage = currentLanguage;
    }
  }

  public initSearch() {
    _.forOwn(this._route.snapshot.queryParams, (value, key) => {
      if (value) {
        if (key === 'page') {
          this.currentPage = parseInt(value, 12);
        }
        this.search[key] = value;
      }
    });
  }

  /**
   * Set meta title
   * @param title
   */
  public setPageTitle(title: string = ''): any {
    this._meta.setTitle(`${this.pageTitle}`);
    this._meta.setTag('og:title', `${this.pageTitle}`);
  }

  /**
   * Set meta keyword
   * @param keyword
   */
  public setMetaKeyword(keyword: string = ''): any {
    this._meta.setTag('keywords', `${keyword}`);
  }

  /**
   * Set meta description
   * @param keyword
   */
  public setMetaDescription(description: string = ''): any {
    // For Google
    this._meta.setTag('description', `${description}`);

    // For Facebook
    this._meta.setTag('og:type', `article`);
    this._meta.setTag('og:description', `${description}`);

    // For Twitter
    this._meta.setTag('twitter:card', `summary`);
    this._meta.setTag('twitter:description', `${description}`);
  }

  /**
   * Set Meta Image
   * @param url
   */
  public setMetaImage(url: string = '') {
    // For Facebook
    this._meta.setTag('og:image', `${url}`);

    // For Twitter
    this._meta.setTag('twitter:image', `${url}`);
  }

  /**
   * Set error message
   * @param message
   */
  public setError(error: any = {}): any {
    if (error.message) {
      this._toastr.error(error.message, '', { timeOut: TOASTR_TIMEOUT });
    } else {
      this._toastr.error(error, '', { timeOut: TOASTR_TIMEOUT });
    }
  }


  /**
   * Set success message
   * @param message
   */
  public setSuccess(message: string): any {
    this._toastr.success(message, '', { timeOut: TOASTR_TIMEOUT });
  }

  /**
   * Set info message
   * @param message
   */

  public setInfo(message: string): any {
    this._toastr.info(message, '', { timeOut: TOASTR_TIMEOUT });
  }

  /**
   * Set warning message
   * @param message
   */
  public setWarning(message: string): any {
    this._toastr.warning(message, '', { timeOut: TOASTR_TIMEOUT });
  }
  /**
   *
   * @param route
   */
  public navigate(route: any[], queryParams: any = {}): any {
    this._router.navigate(route, { queryParams: queryParams });
  }

  /**
   * Back to previous page
   */
  public backToPreviousPage() {
    this._location.back();
  }

  /**
   *
   * @param route
   */
  public navigateByUrl(url: string): any {
    this._router.navigateByUrl(url);
  }

  /**
   * Get List Data
   * @param offset
   */
  public findAll(search: any = null, offset: number = 0): any {
  }

  /**
   * Additional query params for current url.
   * @param queryParams
   */
  public setUrl(queryParams?: any) {
    const url = this.currentLocation.split('?')[0].split('#')[0];

    if (queryParams) {
      this._location.replaceState(url + '?' + UtilHelper.parseFilterToStringNoEmpty(queryParams));
    } else {
      this._location.replaceState(url + '?' + UtilHelper.parseFilterToStringNoEmpty(this.search));
    }
  }

  /**
   * Filter data
   * @param $event
   */
  public filter($event, isScroll: boolean = true): any {
    const name = $event.target.name;
    const value = $event.target.value;
    this.search[name] = value;
    this.pageChanged(1, isScroll);
  }

  /**
   * Check all
   * @param event
   */
  public checkAll(data: any[], event): any {
    this.bulkAll = event.target.checked;
    if (event.target.checked) {
      if (data) {
        this.selectedId = data.map(function (item) {
          return item.id;
        });
      }
    } else {
      this.unCheckAll();
    }
  }

  /**
   * uncheck all
   */
  public unCheckAll(): any {
    this.bulkAll = false;
    this.selectedId = [];
  }

  /**
   * Page Chanage
   * @param event
   */
  public pageChanged(page: any, isScroll: boolean = true): any {
    const offset = (page - 1) * this.itemsPerPage;
    this.currentPage = parseInt(page, 12);
    if (isScroll === true) {
      this.scrollToTop();
    }
    this.search.page = this.currentPage;
    this.search.offset = offset;
    this.findAll(this.search, offset);
    this.setUrl();
    this.unCheckAll();
  }

  /**
   * scroll to top
   */
  public scrollToTop() {
    jQuery('html, body').animate({ scrollTop: 0 }, { duration: 1000 });
  }

  /**
   * Page Size Change
   * @param event
   */
  public pageSizeChanged(event): any {
    const itemsPerPage = event.target.value;
    this.itemsPerPage = itemsPerPage;
    this.search.limit = itemsPerPage;
    this.findAll(this.search);
    this.setUrl();
  }

  /**
   * Check One
   * @param item
   */
  public checkOne(item: any): any {
    const index = this.selectedId.indexOf(item);
    if (index === -1) {
      this.selectedId.push(item);
    } else {
      this.selectedId.splice(index, 1);
    }
  }

  /**
   * show old password
   */
  public showOldPassword(): any {
    this.isShowOldPassword = !this.isShowOldPassword;
    if (this.isShowOldPassword) {
      jQuery('#oldPassword').attr('type', 'text');
    } else {
      jQuery('#oldPassword').attr('type', 'password');
    }
  }

  /**
   * Show password action
   */

  public showPassword(): any {
    this.isShowPassword = !this.isShowPassword;
    if (this.isShowPassword) {
      jQuery('#password').attr('type', 'text');
    } else {
      jQuery('#password').attr('type', 'password');
    }
  }

  /**
   * show password again
   */
  public showPasswordAgain(): any {
    this.isShowPasswordAgain = !this.isShowPasswordAgain;
    if (this.isShowPasswordAgain) {
      jQuery('#passwordAgain').attr('type', 'text');
    } else {
      jQuery('#passwordAgain').attr('type', 'password');
    }
  }

  /**
   * Get Validate Message
   * @param message
   * @returns {string}
   */
  public _t(message: string, params: any = []): string {
    return UtilHelper.translate(message, params);
  }

  /**
   * Sort data
   * @param $event
   */
  public sort(field: string): any {
    this.search.sortBy = field;

    switch (this.isASC) {
      case true:
        this.search.sortType = SORT_TYPES.ASC;
        this.isASC = false;
        break;
      case false:
        this.search.sortType = SORT_TYPES.DESC;
        this.isASC = true;
        break;
      default:
        this.search.sortType = SORT_TYPES.DESC;
        this.isASC = true;
    }
    this.findAll(this.search);
    this.setUrl();
  }

  public trackByIndex(index: number, value: any) {
    return index;
  }

  public isSuperAdmin(): boolean {
    return this.profile.role.id === ROLE.SYSTEM_ADMIN;
  }

  public isManager(): boolean {
    return this.profile.role.id === ROLE.MANAGER;
  }
}

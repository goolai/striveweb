import { NgModule } from '@angular/core';
import { SettingsComponent } from './settings.component';
import { SettingsService } from '../../services';
import { ListComponent, FormAddEditComponent } from './components';
import { SettingsRoutingModule } from './settings-routing.module';
import { SharedModule } from '../../shared/shared.module';
import { UiSwitchModule } from 'ngx-ui-switch';
import { CKEditorModule } from 'ngx-ckeditor';

@NgModule({
  imports: [
    SharedModule,
    SettingsRoutingModule,
    UiSwitchModule,
    CKEditorModule
  ],
  declarations: [
    SettingsComponent,
    ListComponent,
    FormAddEditComponent
  ],
  providers: [
    SettingsService
  ]
})
export class SettingsModule {
}

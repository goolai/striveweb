import { NgbdModalRemoveComponent } from './../../../shared/modals/modals-remove.component';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { DATE_FORMAT, ROLE } from '../../../modules/constants';
import { BaseSearchModel, SettingModel } from '../../../models';
import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { SettingsService, UserIdentityService } from '../../../services';
import { BaseComponent } from '../../base.component';
import { MetaService } from '@ngx-meta/core';
import { Location } from '@angular/common';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-list-setings',
  templateUrl: './list.component.html',
})

export class ListComponent extends BaseComponent implements OnInit {
  public pageTitle = 'Tasks';
  public settings: SettingModel[];
  public DATE_FORMAT = DATE_FORMAT;
  public myProfile: any;

  constructor(
    public _router: Router,
    public _route: ActivatedRoute,
    public _meta: MetaService,
    public _location: Location,
    public _toastr: ToastrService,
    public _modalService: NgbModal,
    public _settingsService: SettingsService) {
    super(_router, _route, _meta, _location, _toastr);

    this.myProfile = UserIdentityService.getProfile();
    this.search = new BaseSearchModel();
    this.initSearch();
  }

  ngOnInit() {
    this.setPageTitle(this.pageTitle);
    this.findAll();
  }

  /**
   * Get all variables
   */
  public findAll(): any {
    try {
      this._settingsService.findAll(true, this.search)
        .then((response) => {
          this.settings = response.data;
          this.totalItems = response.totalItems;
        })
        .catch((error) => {
          this.setError(error);
        });
    } catch (error) {
      this.setError(error);
    }
  }

  /**
   * Update status public/non-public on website
   * @param item
   */
  public switchStatus(item: SettingModel) {
    try {
      item.isPublic = !item.isPublic;

      Promise.resolve()
        .then(() => {
          return this._settingsService.update(item);
        })
        .then((response) => {
          this.setSuccess(response.message);
        })
        .catch((error) => {
          item.isPublic = !item.isPublic;
          this.setError(error);
        });
    } catch (error) {
      item.isPublic = !item.isPublic;
      this.setError(error);
    }
  }

  /**
   * Delete item
   * @param id
   */
  public delete(id: string) {
    const modalRef = this._modalService.open(NgbdModalRemoveComponent);
    modalRef.componentInstance.title = this._t('Delete');
    modalRef.componentInstance.content = this._t('Are you sure you want to remove this item?');

    modalRef.result.then(result => {
      if (result === 'Delete') {
        return this._settingsService.deleteItem(id)
          .then((response) => {
            this.setSuccess(response.message);
            this.findAll();
          })
          .catch((error) => {
            this.setError(error);
          });
      }
    }, (reason) => {
    });
  }

  /**
   * Permission allow add/edit info.
   */
  public permissionAddEditInfo(): boolean {
    let result: boolean = false;

    switch (this.myProfile.roleId) {
      case ROLE.SYSTEM_ADMIN:
      case ROLE.MANAGER:
        result = true;
        break;

      default:
        result = false;
        break;
    }

    return result;
  }
}

import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { SettingModel } from '../../../models';
import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { SettingsService } from '../../../services';
import { BaseComponent } from '../../base.component';
import { MetaService } from '@ngx-meta/core';
import { Location } from '@angular/common';
import { ToastrService } from 'ngx-toastr';
import { CKEDITOR_CONFIG, DATA_TYPE } from '../../../modules';

@Component({
  selector: 'app-create',
  templateUrl: './form.component.html',
})

export class FormAddEditComponent extends BaseComponent implements OnInit {
  public settingModel: SettingModel;
  public CKEDITOR_CONFIG = CKEDITOR_CONFIG;
  public DATA_TYPE = DATA_TYPE;

  constructor(
    public _router: Router,
    public _route: ActivatedRoute,
    public _meta: MetaService,
    public _location: Location,
    public _toastr: ToastrService,
    public _settingsService: SettingsService,
    public _modalService: NgbModal) {
    super(_router, _route, _meta, _location, _toastr);
  }

  ngOnInit() {
    this.pageTitle = (this._route.snapshot.params.id ? 'Edit Settings' : 'Add New Settings');
    this.settingModel = new SettingModel();
    this.setPageTitle();

    if (this._route.snapshot.params.id) {
      // Get variable detail
      this.detail();
    }
  }

  /**
   * Switch status
   */
  public switchStatus() {
    this.settingModel.isPublic = !this.settingModel.isPublic;
  }

  /**
   * Submit information
   */
  public save() {
    try {
      if (this.settingModel.validate('formAction')) {
        Promise.resolve()
          .then(() => {
            if (this.settingModel.type === DATA_TYPE.JSON) {
              this.settingModel.value = JSON.parse(this.settingModel.value);
            }

            if (this.settingModel.id && this.settingModel.id !== '') {
              return this._settingsService.update(this.settingModel);
            } else {
              return this._settingsService.create(this.settingModel);
            }
          })
          .then((response) => {
            this.setSuccess(response.message);
            this.backToPreviousPage();
          })
          .catch((error) => {
            this.setError(error);
          });
      }
    } catch (error) {
      this.setError(error);
    }
  }

  /**
   * Get variable detail
   */
  public detail() {
    try {
      if (this._route.snapshot.params.id) {
        this._settingsService.detail(this._route.snapshot.params.id)
          .then((response) => {
            this.settingModel = response;

            if (this.settingModel.type === DATA_TYPE.JSON) {
              this.settingModel.value = JSON.stringify(this.settingModel.value);
            }
          })
          .catch((error) => {
            this.setError(error);
          });
      }
    } catch (error) {
      this.setError(error);
    }
  }
}

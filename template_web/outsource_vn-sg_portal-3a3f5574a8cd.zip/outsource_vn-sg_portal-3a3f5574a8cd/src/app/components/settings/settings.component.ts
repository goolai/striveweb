
import { Component } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { MetaService } from '@ngx-meta/core';
import { Location } from '@angular/common';
import { BaseComponent } from '../base.component';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-settings',
  template: `<router-outlet></router-outlet>`
})
export class SettingsComponent extends BaseComponent {

  constructor(
    public _router: Router,
    public _route: ActivatedRoute,
    public _meta: MetaService,
    public _location: Location,
    public _toastr: ToastrService,
  ) {
    super(_router, _route, _meta, _location, _toastr);
  }
}

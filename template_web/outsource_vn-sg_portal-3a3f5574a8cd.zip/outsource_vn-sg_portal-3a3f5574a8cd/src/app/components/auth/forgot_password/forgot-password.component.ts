import { ConfigService } from '@ngx-config/core';
import { SESSION, TIME_OUT_REDIRECT, ROLE, REDUX_ACTION } from './../../../modules';
import { UserIdentityService, AuthService } from './../../../services';
import { Location } from '@angular/common';
import { MetaService } from '@ngx-meta/core';
import { ToastrService } from 'ngx-toastr';
import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { UserModel, TokenModel } from '../../../models';
import { BaseComponent } from '../../base.component';

@Component({
    selector: 'app-forgot-password.',
    templateUrl: './forgot-password.component.html',
    styleUrls: ['./forgot-password.component.scss']
})

export class ForgotPasswordComponent extends BaseComponent implements OnInit {

    public user: UserModel;

    constructor(
        public _router: Router,
        public _route: ActivatedRoute,
        public _meta: MetaService,
        public _location: Location,
        public _toastr: ToastrService,
        public _authService: AuthService,
        public _config: ConfigService
    ) {
        super(_router, _route, _meta, _location, _toastr);
    }

    ngOnInit() {
        this.setPageTitle(this.pageTitle);
        if (UserIdentityService.isLoggedIn()) {
            const returnUrl = sessionStorage.getItem(SESSION.PREV_URL_KEYWORD);
            if (returnUrl) {
                this.navigateByUrl(returnUrl);
            } else {
                this.navigate(['dashboard']);
            }
        }

        let defaultLanguage = this._config.getSettings('i18n.defaultLanguage');
        const currentLanguage = sessionStorage.getItem(SESSION.LANGUAGE_KEYWORD);
        defaultLanguage = currentLanguage ? JSON.parse(currentLanguage) : defaultLanguage;
        sessionStorage.setItem(SESSION.LANGUAGE_KEYWORD, JSON.stringify(defaultLanguage));

        this.user = new UserModel();
    }

    // On submit button click

    public forgotPassword(): any {
        try {
            if (this.user.validate('forgotPasswordForm')) {

                this._authService.forgotPassword(this.user)
                    .then((response) => {
                        this._router.navigate(['login']);
                        this.setSuccess(response.message);
                    })
                    .catch(error => {
                        this.setError(error);
                    });

            }
        } catch (error) {
            this.setError(error);
        }
    }
}
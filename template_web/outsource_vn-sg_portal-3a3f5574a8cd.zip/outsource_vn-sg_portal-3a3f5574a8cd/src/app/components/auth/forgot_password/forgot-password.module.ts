import { ForgotPasswordRoutingModule } from './forgot-password-routing.module';
import { NgModule } from '@angular/core';
import { ForgotPasswordComponent } from './forgot-password.component';
import { SharedModule } from '../../../shared/shared.module';
import { AuthService } from '../../../services';

@NgModule({
    imports: [
        ForgotPasswordRoutingModule,
        SharedModule
    ],
    declarations: [
        ForgotPasswordComponent
    ],
    providers: [
        AuthService
    ]
})
export class ForgotPasswordModule { }
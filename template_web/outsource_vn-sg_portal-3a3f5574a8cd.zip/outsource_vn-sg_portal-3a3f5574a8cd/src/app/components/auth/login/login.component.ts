import { ConfigService } from '@ngx-config/core';
import { SESSION, TIME_OUT_REDIRECT, ROLE, REDUX_ACTION } from './../../../modules';
import { UserIdentityService, AuthService } from './../../../services';
import { Location } from '@angular/common';
import { MetaService } from '@ngx-meta/core';
import { ToastrService } from 'ngx-toastr';
import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { UserModel, TokenModel } from '../../../models';
import { BaseComponent } from '../../base.component';

@Component({
    selector: 'app-login',
    templateUrl: './login.component.html',
    styleUrls: ['./login.component.scss']
})

export class LoginComponent extends BaseComponent implements OnInit {

    public user: UserModel;

    constructor(
        public _router: Router,
        public _route: ActivatedRoute,
        public _meta: MetaService,
        public _location: Location,
        public _toastr: ToastrService,
        public _authService: AuthService,
        public _config: ConfigService
    ) {
        super(_router, _route, _meta, _location, _toastr);
    }

    ngOnInit() {
        this.setPageTitle(this.pageTitle);
        if (UserIdentityService.isLoggedIn()) {
            const returnUrl = sessionStorage.getItem(SESSION.PREV_URL_KEYWORD);
            if (returnUrl) {
                this.navigateByUrl(returnUrl);
            } else {
                this.navigate(['dashboard']);
            }
        }

        let defaultLanguage = this._config.getSettings('i18n.defaultLanguage');
        const currentLanguage = sessionStorage.getItem(SESSION.LANGUAGE_KEYWORD);
        defaultLanguage = currentLanguage ? JSON.parse(currentLanguage) : defaultLanguage;
        sessionStorage.setItem(SESSION.LANGUAGE_KEYWORD, JSON.stringify(defaultLanguage));

        this.user = new UserModel();
    }

    // On submit button click
    login() {
        try {
            this.user.removeRule('password', 'validPassword');

            if (this.user.validate('loginForm')) {
                let isValid: boolean = false;
                let tokenInfo: TokenModel;

                return this._authService.login(this.user)
                    .then(response => {
                        if (response && response.user && response.user.roleId) {
                            switch (response.user.roleId) {
                                case ROLE.SYSTEM_ADMIN:
                                case ROLE.MANAGER:
                                    isValid = true;
                                    break;

                                default:
                                    isValid = false;
                            }
                        }
                        if (!isValid) {
                            throw Error(this._t('You do not have permission to access'));
                        } else {
                            tokenInfo = response;
                            UserIdentityService.setCredentials(response);
                            // return this._firebaseService.loginByToken(response.firebaseToken);
                        }
                    })
                    .then(() => {
                        // const returnUrl = this._route.snapshot.queryParams.return;
                        setTimeout(
                            // this.navigateByUrl(returnUrl ? returnUrl : '/dashboard'), TIME_OUT_REDIRECT
                            this.navigateByUrl('dashboard'), TIME_OUT_REDIRECT
                        );
                        return tokenInfo;
                    })
                    .catch(error => {
                        this.setError(error);
                    });
            }
        } catch (error) {
            this.setError(error);
        }
    }
    // On Forgot password link click
    onForgotPassword() {
        this.navigate(['/forgotpassword'], { relativeTo: this._route.parent });
    }
    // On registration link click
    onRegister() {
        // this._route.navigate(['register'], { relativeTo: this._route.parent });
    }
}
import { ROLE } from './../../modules/constants';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { FormComponent, ListComponent } from './components';
import { UsersComponent } from './users.component';
import { AuthGuard } from 'app/services';

const routes: Routes = [
    {
        path: '',
        component: UsersComponent,
        children: [
            {
                path: '',
                component: ListComponent,
                canActivate: [AuthGuard],
                data: {privileges: [ROLE.SYSTEM_ADMIN, ROLE.MANAGER]
                }
            },
            {
                path: 'create',
                component: FormComponent,
                canActivate: [AuthGuard],
                data: {
                    privileges: [ROLE.SYSTEM_ADMIN, ROLE.MANAGER]
                }
            },
            {
                path: 'edit/:id',
                component: FormComponent,
                canActivate: [AuthGuard],
                data: {
                    privileges: [ROLE.SYSTEM_ADMIN, ROLE.MANAGER]
                }
            }
        ]

    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule],
})
export class UsersRoutingModule { }
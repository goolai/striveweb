/**
 * Created by thanhphan on 10/15/16.
 */
import { NgModule } from '@angular/core';
import { UsersComponent } from './users.component';
import { UserService, RoleService, MediaService } from '../../services';
import { ListComponent, FormComponent } from './components';
import { UsersRoutingModule } from './users-routing.module';
import { SharedModule } from '../../shared/shared.module';
import { UiSwitchModule } from 'ngx-ui-switch';
import { AddressService } from './../../services/address.service';
import { AddressCreateFormComponent } from './components/templates/address-create.component';

@NgModule({
  imports: [
    SharedModule,
    UsersRoutingModule,
    UiSwitchModule
  ],
  declarations: [
    UsersComponent,
    ListComponent,
    FormComponent,
    AddressCreateFormComponent
  ],
  providers: [
    UserService,
    RoleService,
    MediaService,
    AddressService
  ],
  entryComponents: [
    AddressCreateFormComponent
  ]
})
export class UsersModule {
}

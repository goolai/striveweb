import { JsonMapper } from './../../../modules/mapper/json.mapper';
import { ROLE, DATE_FORMAT } from '../../../modules/constants';
import { RoleModel } from '../../../models';
import { Component, OnInit, ViewEncapsulation, Input } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { UserService, RoleService, UserIdentityService } from '../../../services';
import { UserModel, SearchUserModel } from '../../../models';
import { BaseComponent } from '../../base.component';
import { MetaService } from '@ngx-meta/core';
import { Location } from '@angular/common';
import { ToastrService } from 'ngx-toastr';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { NgbdModalRemoveComponent } from '../../../shared/modals/modals-remove.component';

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  encapsulation: ViewEncapsulation.None,
})

export class ListComponent extends BaseComponent implements OnInit {
  public pageTitle = 'Users';
  public myProfile: any;
  public search: SearchUserModel;
  public users: UserModel[];
  public user: UserModel;
  public states = [];
  public provinces = [];
  public roles: RoleModel[];
  public ROLE = ROLE;
  public userTag: string[];
  public DATE_FORMAT = DATE_FORMAT;

  constructor(
    public _router: Router,
    public _route: ActivatedRoute,
    public _meta: MetaService,
    public _location: Location,
    public _toastr: ToastrService,
    public _userService: UserService,
    public _modalService: NgbModal,
    public _roleService: RoleService) {
    super(_router, _route, _meta, _location, _toastr);

    this.myProfile = UserIdentityService.getProfile();
    this.search = new SearchUserModel();
    this.user = new UserModel();
    this.initSearch();
  }

  ngOnInit() {
    this.setPageTitle(this.pageTitle);
    this.findAll();
  }

  /**
   * get all user users
   * @param offset
   */
  public findAll(): any {
    this.search.role_id = `${ROLE.ANONYMOUS}`;

    try {
      this._userService.findAll(true, this.search)
        .then((response) => {
          this.users = response.data;
          this.totalItems = response.totalItems;
        })
        .catch((error) => {
          this.setError(error);
        });
    } catch (error) {
      this.setError(error);
    }
  }

  /**
   * delete user
   * @param id
   */
  public delete(id: string) {
    const modalRef = this._modalService.open(NgbdModalRemoveComponent);

    modalRef.componentInstance.title = this._t('Delete');
    modalRef.componentInstance.content = this._t('Are you sure you want to remove this account?');

    modalRef.result.then(result => {
      if (result === 'Delete') {
        return this._userService.delete(id)
          .then((response) => {
            this.findAll();
            this.setSuccess(response.message);
          })
          .catch((error) => {
            this.setError(error);
          });
      }
    }, (reason) => {
    });
  }

  /**
   * create new user
   */
  public updateUser(user: UserModel) {
    let userModel = new UserModel();

    userModel = JsonMapper.deserialize(UserModel, user);
    userModel.isEnable = !user.isEnable;

    try {
      this._userService.update(userModel)
        .then((response) => {
          this.setSuccess(response.message);
        })
        .catch((error) => {
          this.setError(error);
        });
    } catch (error) {
      this.setError(error);
    }
  }

  /**
   * Permission allow edit user info.
   */
  public permissionEditUser(): boolean {
    let result: boolean = false;

    switch (this.myProfile.roleId) {
      case ROLE.SYSTEM_ADMIN:
      case ROLE.MANAGER:
        result = true;
        break;

      default:
        result = false;
        break;
    }

    return result;
  }
}

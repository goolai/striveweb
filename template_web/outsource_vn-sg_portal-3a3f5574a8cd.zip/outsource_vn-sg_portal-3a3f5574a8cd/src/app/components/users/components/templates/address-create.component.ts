import { AddressModel } from './../../../../models/address.model';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { Component, Input, AfterContentInit } from '@angular/core';
import { LocationModel } from 'app/models';

@Component({
  selector: 'ngbd-modal-content',
  templateUrl: './address-create.component.html'
})

export class AddressCreateFormComponent implements AfterContentInit {
  @Input() title;
  @Input() address: AddressModel;

  public cities: LocationModel[];
  public districts: LocationModel[];
  public wards: LocationModel[];

  constructor(
    public activeModal: NgbActiveModal
  ) {
  }

  ngAfterContentInit() {
  }

  /**
   * Save address.
   */
  public submitAddress() {
    if (this.address.validate('formAddressAction') && this.address.regionInfo.validate('formAddressAction')) {
      this.activeModal.close(this.address);
    }
  }
}
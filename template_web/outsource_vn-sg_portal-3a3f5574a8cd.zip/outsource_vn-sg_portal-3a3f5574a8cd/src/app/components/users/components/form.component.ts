import { NgbdModalRemoveComponent } from './../../../shared/modals/modals-remove.component';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { JsonMapper } from './../../../modules/mapper/json.mapper';
import { AddressService } from './../../../services/address.service';
import { AddressModel } from './../../../models/address.model';
import { MediaService } from './../../../services/media.service';
import { MediaModel } from './../../../models/media.model';
import { MOMENT_DATE_FORMAT, GENDER, MAX_SIZE_UPLOAD } from './../../../modules/constants';
import { ROLE, ENABLE_STATUS } from '../../../modules/constants';
import { RoleModel, UserModel, SearchAddressModel } from '../../../models';
import { Component, OnInit, ViewChild } from '@angular/core';
import { Router, ActivatedRoute, Event } from '@angular/router';
import { UserService, RoleService } from '../../../services';
import { BaseComponent } from '../../base.component';
import { MetaService } from '@ngx-meta/core';
import { Location } from '@angular/common';
import { ImageHelper, DateHelper } from '../../../helpers';
import { ToastrService } from 'ngx-toastr';
import { AddressCreateFormComponent } from './templates/address-create.component';

@Component({
  selector: 'app-create',
  templateUrl: './form.component.html',
})
export class FormComponent extends BaseComponent implements OnInit {
  public pageTitle = 'Users';
  public user: UserModel;
  public states = [];
  public roles: RoleModel[];
  public ROLE = ROLE;
  public GENDER = GENDER;
  private media: MediaModel;

  public addressList: AddressModel[];
  public address: AddressModel;
  public search: SearchAddressModel;

  @ViewChild('addressModal') private addressModal;

  constructor(
    public _router: Router,
    public _route: ActivatedRoute,
    public _meta: MetaService,
    public _location: Location,
    public _toastr: ToastrService,
    public _roleService: RoleService,
    public _modalService: NgbModal,
    public _mediaService: MediaService,
    public _addressService: AddressService,
    public _userService: UserService) {
    super(_router, _route, _meta, _location, _toastr);

  }

  ngOnInit() {
    this.pageTitle = (this._route.snapshot.params.id ? 'Edit User' : 'Add User');
    this.setPageTitle();
    this.user = new UserModel();
    this.address = new AddressModel();
    this.search = new SearchAddressModel();

    this.user.roleId = '';
    this.user.gender = '';
    if (this._route.snapshot.params.id) {
      // get detail
      this.detail();
      this.search.user_id = this._route.snapshot.params.id;
      this.findAll();
    } else {
      this.user.isEnable = ENABLE_STATUS.YES;
    }
    this.getData();

  }

  /**
   * create user users
   */
  public save() {
    try {
      if (this.user.id) {
        this.user.removeRule('newPassword', 'required');
        this.user.removeRule('newPassword', 'validPassword');
      }
      if (this.user.validate('formAction')) {
        Promise.resolve()
          .then(() => {
            if (this.user.id) {
              return this._userService.update(this.user);
            } else {
              return this._userService.create(this.user);
            }
          })
          .then((response) => {
            this.setSuccess(response.message);
            this.backToPreviousPage();
          })
          .catch((error) => {
            this.setError(error);
          });
      }
    } catch (error) {
      this.setError(error);
    }
  }

  public getData(): any {
    try {
      // get list role
      this._roleService.findAll(false)
        .then((response) => {
          this.roles = response.data;
        })
        .catch((error) => {
          this.setError(error);
        });
    } catch (error) {
      this.setError(error);
    }

  }

  public detail() {
    try {
      if (this._route.snapshot.params.id) {
        this._userService.findById(this._route.snapshot.params.id)
          .then((response) => {
            this.user = response;
            if (this.user.dob) {
              this.user.dob = DateHelper.toFormat(this.user.dob, MOMENT_DATE_FORMAT.YYYY_MM_DD);
            }
          })
          .catch((error) => {
            this.setError(error);
          });
      }
    } catch (error) {
      this.setError(error);
    }
  }

  /**
   *
   */
  public selectedRole() {

  }
  /**
   *
   */
  public switchStatus() {
    this.user.isEnable = !this.user.isEnable;
  }

  /**
   *
   * @param
   */
  public onFileSelected($event): any {
    this.media = new MediaModel();
    let message: string;
    let isValid: boolean = true;
    let mediaModel = new MediaModel();
    let image: any = new Image();
    let file: File = $event.target.files[0];
    let reader: FileReader = new FileReader();
    let self = this;
    if (ImageHelper.isValidImage(file.type)) {
      if (ImageHelper.isValidFileSize(file.size)) {
        reader.onload = (loadEvent: any) => {
          image.src = loadEvent.target.result;
        };
        reader.readAsDataURL(file);
        image.onload = function () {

          self.media.file = file;
          self.media.type = 'image';
          self._mediaService.uploadImage(self.media)
            .then(item => {
              self.user.avatarId = item.id;

              self.user.avatar = item;
            })
            .catch(err => {
              self.setError(err);
            });
        };
      } else {
        message = this._t(`File upload too large. Only allow {0}MB.`, MAX_SIZE_UPLOAD);
      }
    } else {
      message = this._t('Only allow file *.png , *.jpg.');
    }
    if (message) {
      self.setError(message);
    }
  }

  /**
   * get all
   * @param offset
   */
  public findAll(): any {
    this.search.user_id = this._route.snapshot.params.id;
    if (this.search.user_id) {
      try {
        this._addressService.findAll(true, this.search)
          .then((response) => {
            this.addressList = response.data;
            this.totalItems = response.totalItems;
          })
          .catch((error) => {
            this.setError(error);
          });
      } catch (error) {
        this.setError(error);
      }
    }
  }

  /**
   * delete
   * @param id
   */
  public delete(id: string) {
    const modalRef = this._modalService.open(NgbdModalRemoveComponent);
    modalRef.componentInstance.title = this._t('Delete');
    modalRef.componentInstance.content = this._t('Are you sure you want to remove this item?');

    modalRef.result.then(result => {
      if (result === 'Delete') {
        return this._addressService.delete(id)
          .then((response) => {
            this.findAll();
            this.setSuccess(response.message);
          })
          .catch((error) => {
            this.setError(error);
          });
      }
    });
  }

  /**
   *
   */
  public update(item: AddressModel) {
    let addressModel = new AddressModel();

    addressModel = JsonMapper.deserialize(AddressModel, item);
    addressModel.isDefault = addressModel.isDefault === 0 ? 1 : 0;
    addressModel.userId = this.search.user_id;
    try {
      this._addressService.updateSetDefault(addressModel)
        .then((response) => {
          this.setSuccess(response.message);
          this.findAll();
        })
        .catch((error) => {
          this.setError(error);
        });
    } catch (error) {
      this.setError(error);
    }
  }
  /**
   * create
   */
  public createEdit() {
    this.address.userId = this._route.snapshot.params.id;
    try {
      Promise.resolve()
        .then(() => {
          if (this.address.id) {
            return this._addressService.update(this.address);
          } else {
            return this._addressService.create(this.address);
          }
        })
        .then((response) => {
          this.setSuccess(response.message);
          this.findAll();
        })
        .catch((error) => {
          this.setError(error);
        });
    } catch (error) {
      this.setError(error);
    }
  }

  /**
   * create/edit
   */
  public createFormModal(isShow: boolean = true, item?: AddressModel) {
    const modalRef = this._modalService.open(AddressCreateFormComponent);

    if (item) {
      // show modal edit
      modalRef.componentInstance.title = this._t('Edit address');
      this.address = JsonMapper.deserialize(AddressModel, item);
      modalRef.componentInstance.address = this.address;

    } else {
      // show modal add
      modalRef.componentInstance.title = this._t('Add new address');
      modalRef.componentInstance.address = new AddressModel();
    }

    modalRef.result.then((result) => {
      if (result) {
        this.address = result;
        this.createEdit();
      }
    }).catch((error) => {
    });
  }
}

import { NgModule } from '@angular/core';
import { NotificationMessagesComponent } from './notification_messages.component';
import { NotificationsService, MediaService } from '../../services';
import { ListComponent, FormAddEditComponent } from './components';
import { NotificationMessagesRoutingModule } from './notification_messages-routing.module';
import { SharedModule } from '../../shared/shared.module';
import { UiSwitchModule } from 'ngx-ui-switch';
import { CKEditorModule } from 'ngx-ckeditor';

@NgModule({
  imports: [
    SharedModule,
    NotificationMessagesRoutingModule,
    UiSwitchModule,
    CKEditorModule
  ],
  declarations: [
    NotificationMessagesComponent,
    ListComponent,
    FormAddEditComponent,
  ],
  providers: [
    NotificationsService,
    MediaService,
  ]
})
export class NotificationMessagesModule {
}

import { ROLE } from '../../modules/constants';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { FormAddEditComponent, ListComponent } from './components';
import { NotificationMessagesComponent } from './notification_messages.component';
import { AuthGuard } from 'app/services';

const routes: Routes = [
    {
        path: '',
        component: NotificationMessagesComponent,
        children: [
            {
                path: '',
                component: ListComponent,
                canActivate: [AuthGuard],
                data: {
                    privileges: [ROLE.SYSTEM_ADMIN, ROLE.MANAGER]
                }
            },
            {
                path: 'create',
                component: FormAddEditComponent,
                canActivate: [AuthGuard],
                data: {
                    privileges: [ROLE.SYSTEM_ADMIN, ROLE.MANAGER]
                }
            }
        ]
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule],
})
export class NotificationMessagesRoutingModule { }
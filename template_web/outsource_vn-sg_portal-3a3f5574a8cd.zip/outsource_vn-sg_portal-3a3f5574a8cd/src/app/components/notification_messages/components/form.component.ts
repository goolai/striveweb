import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { NotificationMessageModel, MediaModel, BaseSearchModel, } from '../../../models';
import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { SettingsService, NotificationsService, MediaService } from '../../../services';
import { BaseComponent } from '../../base.component';
import { MetaService } from '@ngx-meta/core';
import { Location } from '@angular/common';
import { ToastrService } from 'ngx-toastr';
import { CKEDITOR_CONFIG, DATA_TYPE, MAX_SIZE_UPLOAD, FCM_PUSH_TYPE, FCM_PUSH_TYPE_ARR } from '../../../modules';
import { ImageHelper } from 'app/helpers';

@Component({
  selector: 'app-create-push-notification',
  templateUrl: './form.component.html',
})

export class FormAddEditComponent extends BaseComponent implements OnInit {
  public messageModel: NotificationMessageModel;
  public media: MediaModel;
  public CKEDITOR_CONFIG = CKEDITOR_CONFIG;
  public DATA_TYPE = DATA_TYPE;
  public FCM_TYPE = FCM_PUSH_TYPE;
  public FCM_PUSH_TYPE_ARR = FCM_PUSH_TYPE_ARR;
  public filterProductAvalable: BaseSearchModel;

  constructor(
    public _router: Router,
    public _route: ActivatedRoute,
    public _meta: MetaService,
    public _location: Location,
    public _toastr: ToastrService,
    public _notificationService: NotificationsService,
    public _mediaService: MediaService,
    public _modalService: NgbModal) {
    super(_router, _route, _meta, _location, _toastr);
    this.media = new MediaModel();
    this.filterProductAvalable = new BaseSearchModel();
  }

  ngOnInit() {
    this.pageTitle = (this._route.snapshot.params.id ? 'Edit notification message' : 'Create notification message');
    this.messageModel = new NotificationMessageModel();
    this.setPageTitle();

    if (this._route.snapshot.params.id) {
      // Get message detail
      this.detail();
    }
  }

  /**
   * Submit information
   */
  public save() {
    try {
      if (this.messageModel.validate('formAction')) {
        switch (this.messageModel.type) {
          case this.FCM_TYPE.WEB:
            if (this.messageModel.link == null || this.messageModel.link === '') {
              this.setError(this._t('This field is required'));
              return;
            }
            break;

          case this.FCM_TYPE.PRODUCT:
            if (this.messageModel.productId == null || this.messageModel.productId === '') {
              this.setError(this._t('This field is required'));
              return;
            }
            break;

          default:
            break;
        }

        Promise.resolve()
          .then(() => {
            if (this.messageModel.id && this.messageModel.id !== '') {
              // return this._notificationService.update(this.messageModel);
              return null;
            } else {
              return this._notificationService.createNewPushMessage(this.messageModel);
            }
          })
          .then((response) => {
            this.setSuccess(response.message);
            this.backToPreviousPage();
          })
          .catch((error) => {
            this.setError(error);
          });
      }
    } catch (error) {
      this.setError(error);
    }
  }

  /**
   * Get product name.
   * @param item
   */
  public displayProductName(item: any): string {
    let result: string = '';

    result = `${item.name} - ${item.sku}`;

    return result;
  }

  /**
   * Get message detail
   */
  public detail() {
    try {
      // if (this._route.snapshot.params.id) {
      //   this._notificationService.detail(this._route.snapshot.params.id)
      //     .then((response) => {
      //       this.messageModel = response;

      //       if (this.messageModel.type === DATA_TYPE.JSON) {
      //         this.messageModel.value = JSON.stringify(this.messageModel.value);
      //       }
      //     })
      //     .catch((error) => {
      //       this.setError(error);
      //     });
      // }
    } catch (error) {
      this.setError(error);
    }
  }

  /**
   * Upload icon image.
   * @param $event
   */
  public onIconSelected($event): any {
    let message: string;
    let image: any = new Image();
    let file: File = $event.target.files[0];
    let reader: FileReader = new FileReader();
    let self = this;

    if (ImageHelper.isValidImage(file.type)) {
      if (ImageHelper.isValidFileSize(file.size)) {
        reader.onload = (loadEvent: any) => {
          image.src = loadEvent.target.result;
        };

        reader.readAsDataURL(file);
        image.onload = function () {
          self.media.file = file;
          self.media.type = 'image';

          self._mediaService.uploadImage(self.media)
            .then(item => {
              self.messageModel.icon = item.url;
            })
            .catch(err => {
              self.setError(err);
            });
        };
      } else {
        message = this._t(`File upload too large. Only allow {0}MB.`, MAX_SIZE_UPLOAD);
      }
    } else {
      message = this._t('Only allow file *.png , *.jpg.');
    }
    if (message) {
      self.setError(message);
    }
  }

  /**
   * Upload cover image
   * @param $event
   */
  public onCoverImageSelected($event): any {
    let message: string;
    let image: any = new Image();
    let file: File = $event.target.files[0];
    let reader: FileReader = new FileReader();
    let self = this;

    if (ImageHelper.isValidImage(file.type)) {
      if (ImageHelper.isValidFileSize(file.size)) {
        reader.onload = (loadEvent: any) => {
          image.src = loadEvent.target.result;
        };

        reader.readAsDataURL(file);
        image.onload = function () {
          self.media.file = file;
          self.media.type = 'image';

          self._mediaService.uploadImage(self.media)
            .then(item => {
              self.messageModel.image = item.url;
            })
            .catch(err => {
              self.setError(err);
            });
        };
      } else {
        message = this._t(`File upload too large. Only allow {0}MB.`, MAX_SIZE_UPLOAD);
      }
    } else {
      message = this._t('Only allow file *.png , *.jpg.');
    }
    if (message) {
      self.setError(message);
    }
  }
}

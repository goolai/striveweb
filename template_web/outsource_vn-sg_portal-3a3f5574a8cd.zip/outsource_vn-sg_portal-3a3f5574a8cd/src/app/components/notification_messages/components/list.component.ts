import { NgbdModalRemoveComponent } from '../../../shared/modals/modals-remove.component';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { BaseSearchModel, NotificationMessageModel } from '../../../models';
import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { NotificationsService } from '../../../services';
import { BaseComponent } from '../../base.component';
import { MetaService } from '@ngx-meta/core';
import { Location } from '@angular/common';
import { ToastrService } from 'ngx-toastr';
import {
  DATA_TYPE, DATE_FORMAT,
  ENABLE_STATUS_ARR,
} from 'app/modules';

@Component({
  selector: 'app-list-messages',
  templateUrl: './list.component.html',
})

export class ListComponent extends BaseComponent implements OnInit {
  public pageTitle = 'Notification messages';
  public listMessages: NotificationMessageModel[];
  public DATA_TYPE = DATA_TYPE;
  public DATE_FORMAT = DATE_FORMAT;
  public STATUS_ARR = ENABLE_STATUS_ARR;

  constructor(
    public _router: Router,
    public _route: ActivatedRoute,
    public _meta: MetaService,
    public _location: Location,
    public _toastr: ToastrService,
    public _modalService: NgbModal,
    public _notificationService: NotificationsService) {
    super(_router, _route, _meta, _location, _toastr);

    this.search = new BaseSearchModel();
    this.initSearch();
  }

  ngOnInit() {
    this.setPageTitle(this.pageTitle);
    this.findAll();
  }

  /**
   * Get all messages
   */
  public findAll(): any {
    try {
      this._notificationService.findAllNotificationMessages(true, this.search)
        .then((response) => {
          this.listMessages = response.data;
          this.totalItems = response.totalItems;
        })
        .catch((error) => {
          this.setError(error);
        });
    } catch (error) {
      this.setError(error);
    }
  }

  /**
   * Get cover image for product.
   * @param item
   */
  public getCoverImage(item: NotificationMessageModel) {
    let coverImage: string = '';

    return coverImage;
  }

  /**
   * Delete message
   * @param id
   */
  public delete(id: string) {
    const modalRef = this._modalService.open(NgbdModalRemoveComponent);
    modalRef.componentInstance.title = this._t('Delete');
    modalRef.componentInstance.content = this._t('Are you sure you want to remove this item?');

    modalRef.result.then(result => {
      if (result === 'Delete') {
        // return this._notificationService.deleteMessage(id)
        //   .then((response) => {
        //     this.setSuccess(response.message);
        //     this.findAll();
        //   })
        //   .catch((error) => {
        //     this.setError(error);
        //   });
      }
    }, (reason) => {
    });
  }
}

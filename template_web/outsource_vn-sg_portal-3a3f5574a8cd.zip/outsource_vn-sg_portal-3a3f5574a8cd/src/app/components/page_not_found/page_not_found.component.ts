import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-error-page',
    templateUrl: './page_not_found.component.html',
    styleUrls: ['./page_not_found.component.scss']
})

export class PageNotFoundComponent {
}
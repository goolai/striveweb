import { NgModule } from '@angular/core';
import { PageNotFoundComponent } from './page_not_found.component';
import { PageNotFoundRoutingModule } from './page_not_found_routing.module';
import { SharedModule } from '../../shared/shared.module';

@NgModule({
  imports: [
    SharedModule,
    PageNotFoundRoutingModule
  ],
  declarations: [
    PageNotFoundComponent
  ],
  providers: [
  ],
  entryComponents: [
  ]
})

export class PageNotFoundModule {
}

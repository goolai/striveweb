import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { PageNotFoundComponent } from './page_not_found.component';

const routes: Routes = [
    {
        path: '',
        component: PageNotFoundComponent,
        children: [
            {
                path: 'page_not_found',
                data: {
                    privileges: []
                }
            }
        ]

    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule],
})

export class PageNotFoundRoutingModule { }
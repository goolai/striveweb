import { MediaService } from './../../services/media.service';
import { UserIdentityService } from './../../services/user-identity.service';
import { DateHelper } from './../../helpers/date.helper';
import { UserService } from './../../services/user.service';
import { Component, OnInit } from '@angular/core';
import { BaseComponent } from '../base.component';
import { Router, ActivatedRoute } from '@angular/router';
import { MetaService } from '@ngx-meta/core';
import { Location } from '@angular/common';
import { ToastrService } from 'ngx-toastr';
import { UserModel, MediaModel } from 'app/models';
import { GlobalState } from '../../global.state';
import { MOMENT_DATE_FORMAT, STATE_EVENT, ROLE, GENDER, MAX_SIZE_UPLOAD, AVATAR_DEFAULT } from './../../modules/constants';
import { ImageHelper } from '../../helpers';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.scss']
})

export class ProfileComponent extends BaseComponent implements OnInit {

  // Variable Declaration
  public user: UserModel;
  public isReadonlyPhone: boolean = false;
  public isReadonlyEmail: boolean = false;
  public GENDER = GENDER;
  private media: MediaModel;
  public AVATAR_DEFAULT = AVATAR_DEFAULT;

  constructor(
    public _router: Router,
    public _route: ActivatedRoute,
    public _meta: MetaService,
    public _userService: UserService,
    public _location: Location,
    public _mediaService: MediaService,
    private _state: GlobalState,
    public _toastr: ToastrService) {
    super(_router, _route, _meta, _location, _toastr);
  }

  ngOnInit() {
    this.user = new UserModel();
    this.media = new MediaModel();

    this.getProfile();
  }

  public save() {
    try {
      if (this.user.validate('formAction')) {
        return this._userService.updateProfile(this.user)
          .then((response) => {
            this.setSuccess(response.message);
            this.getProfile();
            // this.navigate(['/admin/account']);
          })
          .catch((error) => {
            this.setError(error);
          });
      }
    } catch (error) {
      this.setError(error);
    }
  }

  /**
   * Get user profile.
   */
  public getProfile() {
    try {
      this._userService.getProfile()
        .then((response) => {
          this.user = response;
          if (this.user.dob) {
            this.user.dob = DateHelper.toFormat(this.user.dob, MOMENT_DATE_FORMAT.YYYY_MM_DD);
          }
          if (!response.passwordAgain) {
            this.isReadonlyPhone = false;
          } else {
            this.isReadonlyPhone = true;
          }
          if (response.roleId === ROLE.SYSTEM_ADMIN) {
            this.isReadonlyEmail = false;
          } else {
            this.isReadonlyEmail = true;
          }
          UserIdentityService.setProfile(response);
          this._state.notifyDataChanged(STATE_EVENT.UPDATE_PROFILE, this.user); // notify update profile
          this.profile = UserIdentityService.getProfile();
        })
        .catch((error) => {
          this.setError(error);
        });
    } catch (error) {
      this.setError(error);
    }
  }

  /**
   * Change password
   */
  public changePassword(): any {
    try {
      if (this.user.validate('formChangePassword')) {
        this._userService.changePassword(this.user)
          .then(response => {
            if (response) {
              this.setSuccess(this._t('Change password successful.'));
              // UserIdentityService.setCredentials(response);
            }
          })
          .catch(error => {
            this.setError(error);
          });
      }
    } catch (error) {
      this.setError(error);
    }
  }

  public onFileSelected($event): any {
    let message: string;
    let isValid: boolean = true;
    let mediaModel = new MediaModel();
    let image: any = new Image();
    let file: File = $event.target.files[0];
    let reader: FileReader = new FileReader();
    let self = this;
    if (ImageHelper.isValidImage(file.type)) {
      if (ImageHelper.isValidFileSize(file.size)) {
        reader.onload = (loadEvent: any) => {
          image.src = loadEvent.target.result;
        };
        reader.readAsDataURL(file);
        image.onload = function () {

          self.media.file = file;
          self.media.type = 'image';
          self._mediaService.uploadImage(self.media)
            .then(item => {
              self.user.avatarId = item.id;

              self.user.avatar = item;
              self.save();
            })
            .catch(err => {
              self.setError(err);
            });
        };
      } else {
        message = this._t(`File upload too large. Only allow {0}MB.`, MAX_SIZE_UPLOAD);
      }
    } else {
      message = this._t('Only allow file *.png , *.jpg.');
    }
    if (message) {
      self.setError(message);
    }
  }
}
import { JsonMapper } from '../modules/mapper/json.mapper';
import { BaseModel } from './base.model';
import { UtilHelper } from '../helpers/util.helper';
import { RoleModel } from './role.model';
import {
  IMAGE_EXTENSION,
  INPUT_MAXLENGTH,
  MAX_SIZE_UPLOAD,
} from '../modules/constants';
import { ValidateModel } from './validate.model';
import { Json } from '../modules';
import { MediaModel } from './media.model';

export class UserModel extends BaseModel {
  @Json('email')
  public email: string = undefined;

  @Json('avatarUrl')
  public avatarUrl: string = undefined;

  @Json('oldPassword')
  public oldPassword: string = undefined;

  @Json('newPassword')
  public newPassword: string = undefined;

  @Json('password')
  public password: string = undefined;

  @Json('passwordAgain')
  public passwordAgain: string = undefined;

  @Json('name')
  public name: string = undefined;

  @Json('roleId')
  public roleId: string = undefined;

  // => Support wrong key in statusHistory => Will be fixed in future.
  @Json('roldId')
  public roldId: string = undefined;

  @Json('avatarId')
  public avatarId: string = undefined;

  @Json('phoneNumber')
  public phoneNumber: string = undefined;

  @Json('referralsBy')
  public referralsBy: string = undefined;

  @Json('gender')
  public gender: string = undefined;

  @Json('dayOfBirth')
  public dayOfBirth: string = undefined;

  @Json('dob')
  public dob: string = undefined;

  @Json('lastLogin')
  public lastLogin: string = undefined;

  @Json('isVip')
  public isVip: number = undefined;

  @Json('isVerifiedPhone')
  public isVerifiedPhone: number = undefined;

  @Json('fromPlatform')
  public fromPlatform: string = undefined;        // Register from platform: android, ios or web

  @Json('fromDeviceId')
  public fromDeviceId: string = undefined;        // Register from device?

  @Json('fromIPAddress')
  public fromIPAddress: string = undefined;       // Register from ip address?

  @Json('totalPoints')
  public totalPoints: number = undefined;

  @Json('totalTimesCancelOrder')
  public totalTimesCancelOrder: number = undefined;

  @Json('lastTimeCancelOrder')
  public lastTimeCancelOrder: string = undefined;

  @Json({ name: 'avatar', clazz: MediaModel, omitEmpty: true })
  public avatar: MediaModel = undefined;

  @Json({ name: 'role', clazz: RoleModel, omitEmpty: true, ignore: true })
  public role: RoleModel = undefined;

  constructor() {
    super();
    this.validateRules = new ValidateModel();
    this.initValidateRules();
  }

  /**
   * init validate rule
   * @returns {ValidateModel}
   */
  public initValidateRules(): ValidateModel {

    this.addRule('name', 'required', true, this._t('This field is required'));
    this.addRule('name', 'maxLength', INPUT_MAXLENGTH, this._t(`Maximum {0} characters.`, INPUT_MAXLENGTH));

    this.addRule('phoneNumber', 'required', true, this._t('This field is required'));
    this.addRule('phoneNumber', 'number', true, this._t('This field is required'));
    this.addRule('phoneNumber', 'maxLength', INPUT_MAXLENGTH, this._t(`Maximum {0} characters.`, INPUT_MAXLENGTH));

    this.addRule('email', 'required', true, this._t('This field is required'));
    this.addRule('email', 'formatEmail', true, this._t('Invalid email address'));
    this.addRule('email', 'maxLength', INPUT_MAXLENGTH, this._t(`Maximum {0} characters.`, INPUT_MAXLENGTH));

    this.addRule('oldPassword', 'required', true, this._t('This field is required'));
    this.addRule('newPassword', 'required', true, this._t('This field is required'));
    this.addRule('password', 'required', true, this._t('This field is required'));
    this.addRule('password', 'validPassword', true, this._t('Password must be at least 6 characters including both alphabets and numbers'));
    this.addRule('newPassword', 'validPassword', true, this._t('Password must be at least 6 characters including both alphabets and numbers'));
    this.addRule('passwordAgain', 'equalTo', '#newPassword', this._t('Password and confirm password does not match'));
    this.addRule('roleId', 'required', true, this._t('This field is required'));
    this.addRule('avatarUrl', 'required', true, this._t('This field is required'));
    this.addRule('avatarUrl', 'extension', IMAGE_EXTENSION, this._t('Only allow file *.png , *.jpg.'));
    this.addRule('avatarUrl', 'maxSizeUpload', MAX_SIZE_UPLOAD, this._t(`File upload too large. Only allow {0}MB.`, MAX_SIZE_UPLOAD));
    this.addRule('gender', 'required', true, this._t('This field is required'));
    this.addRule('dob', 'required', true, this._t('This field is required'));

    return this.getRules();
  }

  /**
   *
   * @param data
   * @returns {UserModel}
   */
  public static toChangePasswordResquest(data: UserModel): UserModel {
    let model: any = {};

    model.password = UtilHelper.setDataDefault(data.password);
    model.newPassword = UtilHelper.setDataDefault(data.newPassword);

    return model;
  }
  /**
   *
   * @param data
   * @returns {UserModel}
   */
  public static toProfileModel(data: UserModel): UserModel {
    let model: any = {};

    model.id = UtilHelper.setDataDefault(data.id);
    model.roleId = UtilHelper.setDataDefault(data.roleId);
    model.email = UtilHelper.setDataDefault(data.email);
    model.phoneNumber = UtilHelper.setDataDefault(data.phoneNumber);
    model.avatarId = UtilHelper.setDataDefault(data.avatarId);

    model.dob = UtilHelper.setDataDefault(data.dob);
    model.avatar = UtilHelper.setDataDefault(data.avatar);
    model.name = UtilHelper.setDataDefault(data.name);

    if (data.role) {
      model.role = JsonMapper.deserialize(RoleModel, data.role);
    }
    return model;
  }
}
import { BaseModel } from './base.model';
import { Json, INPUT_MAXLENGTH } from '../modules';
import { ValidateModel } from './validate.model';

export class SettingModel extends BaseModel {
    @Json('value')
    public value: string = undefined;

    @Json('keyword')
    public keyword: string = undefined;

    @Json('type')
    public type: string = undefined;

    @Json('desc')
    public desc: string = undefined;

    @Json('slug')
    public slug: string = undefined;

    @Json('isPublic')
    public isPublic: boolean = undefined;

    constructor() {
        super();
        this.validateRules = new ValidateModel();
        this.initValidateRules();
    }

    /**
     * Initial rule
     */
    public initValidateRules(): ValidateModel {
        this.addRule('keyword', 'required', true, this._t('This field is required'));
        this.addRule('keyword', 'maxLength', INPUT_MAXLENGTH, this._t(`Maximum {0} characters.`, INPUT_MAXLENGTH));

        this.addRule('value', 'required', true, this._t('This field is required'));
        this.addRule('type', 'required', true, this._t('This field is required'));

        return this.getRules();
    }
}

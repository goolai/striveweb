import { BaseModel } from './base.model';
import { ValidateModel } from './validate.model';
import { MAX_SIZE_UPLOAD, IMAGE_EXTENSION } from '../modules/constants';
import { Json } from '../modules';

export class MediaModel extends BaseModel {
  @Json('file')
  public file: any = undefined;

  @Json('image')
  public image: any = undefined;

  @Json('path')
  public path: string = undefined;

  @Json('url')
  public url: string = undefined;

  @Json('type')
  public type: string = undefined;

  constructor() {
    super();
    this.validateRules = new ValidateModel();
    this.initValidateRules();
  }

  /**
   *
   * @returns {ValidateModel}
   */
  public initValidateRules(): ValidateModel {
    this.addRule('image', 'required', true, this._t('This field is required'));
    this.addRule('image', 'extension', IMAGE_EXTENSION, this._t('Only allow file *.png , *.jpg.'));
    this.addRule('image', 'maxSizeUpload', MAX_SIZE_UPLOAD, this._t(`File upload too large. Only allow {0}MB.`, MAX_SIZE_UPLOAD));

    return this.getRules();
  }
}
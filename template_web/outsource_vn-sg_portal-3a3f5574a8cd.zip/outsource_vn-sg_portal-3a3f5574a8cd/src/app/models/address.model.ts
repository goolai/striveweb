import { BaseModel } from './base.model';
import {
  INPUT_MAXLENGTH, INPUT_NUMBER_MAX_LENGTH,
} from '../modules/constants';
import { ValidateModel } from './validate.model';
import { Json } from '../modules';
import { RegionInfoModel } from './region_info.model';

export class AddressModel extends BaseModel {

  @Json('userId')
  public userId: string = undefined;

  @Json('contactName')
  public contactName: string = undefined;

  @Json('contactNumber')
  public contactNumber: string = undefined;

  @Json('address')
  public address: string = undefined;

  @Json('ward')
  public ward: string = undefined;

  @Json('district')
  public district: string = undefined;

  @Json('city')
  public city: string = undefined;

  @Json('state')
  public state: string = undefined;

  @Json('postalCode')
  public postalCode: string = undefined;

  @Json('country')
  public country: string = undefined;

  @Json({ name: 'regionInfo', clazz: RegionInfoModel, omitEmpty: true })
  public regionInfo: RegionInfoModel = undefined;

  @Json('isDefault')
  public isDefault: number = undefined;

  constructor() {
    super();
    this.userId = '';
    this.id = '';
    this.regionInfo = new RegionInfoModel();
    this.validateRules = new ValidateModel();
    this.initValidateRules();
  }

  /**
   * init validate rule
   * @returns {ValidateModel}
   */
  public initValidateRules(): ValidateModel {
    this.addRule('contactName', 'required', true, this._t('This field is required'));
    this.addRule('contactName', 'maxLength', INPUT_MAXLENGTH, this._t(`Maximum {0} characters.`, INPUT_MAXLENGTH));

    this.addRule('contactNumber', 'required', true, this._t('This field is required'));
    this.addRule('contactNumber', 'maxLength', INPUT_MAXLENGTH, this._t(`Maximum {0} characters.`, INPUT_NUMBER_MAX_LENGTH));
    this.addRule('contactNumber', 'number', true, this._t('Phone number is invalid'));

    this.addRule('address', 'required', true, this._t('This field is required'));
    this.addRule('address', 'maxLength', INPUT_MAXLENGTH, this._t(`Maximum {0} characters.`, INPUT_MAXLENGTH));

    // this.addRule('ward', 'required', true, this._t('This field is required'));
    // this.addRule('ward', 'maxLength', INPUT_MAXLENGTH, this._t(`Maximum {0} characters.`, INPUT_MAXLENGTH));

    // this.addRule('district', 'required', true, this._t('This field is required'));
    // this.addRule('district', 'maxLength', INPUT_MAXLENGTH, this._t(`Maximum {0} characters.`, INPUT_MAXLENGTH));

    // this.addRule('city', 'required', true, this._t('This field is required'));
    // this.addRule('city', 'maxLength', INPUT_MAXLENGTH, this._t(`Maximum {0} characters.`, INPUT_MAXLENGTH));

    // this.addRule('country', 'required', true, this._t('This field is required'));
    // this.addRule('country', 'maxLength', INPUT_MAXLENGTH, this._t(`Maximum {0} characters.`, INPUT_MAXLENGTH));

    return this.getRules();
  }
}
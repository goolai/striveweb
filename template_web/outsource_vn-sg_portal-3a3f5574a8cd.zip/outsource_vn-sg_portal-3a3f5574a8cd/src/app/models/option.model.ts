/**
 * Created by thanhphan on 10/15/16.
 */
import { BaseModel } from './base.model';
import { Json } from '../modules/mapper/json.decorator';

export class OptionModel extends BaseModel {
  @Json('title')
  public title: string = undefined;

  @Json('keyword')
  public keyword: string = undefined;

  constructor() {
    super();
  }

  /**
   *
   * @param _title
   * @param _keyword
   * @returns {OptionModel}
   */
  public static init(_title: string, _keyword: any): OptionModel {
    const ret = new OptionModel();
    ret.title = _title;
    ret.keyword = _keyword;

    return ret;
  }
}

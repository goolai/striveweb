import { BaseModel } from './base.model';
import { ValidateModel } from './validate.model';
import { Json } from '../modules';

export class LocationModel extends BaseModel {

  @Json('name')
  public name: string = undefined;

  @Json('parent')
  public parent: string = undefined;

  constructor() {
    super();
    this.validateRules = new ValidateModel();
    this.initValidateRules();
  }

  /**
   * Init validate rule
   * @returns {ValidateModel}
   */
  public initValidateRules(): ValidateModel {
    return this.getRules();
  }
}
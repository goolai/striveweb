import { BaseModel } from './base.model';
import { Json, INPUT_NUMBER_MAX_LENGTH, INPUT_MAXLENGTH } from '../modules';
import { ValidateModel } from './validate.model';

export class NotificationMessageModel extends BaseModel {
    @Json('type')
    public type: string = undefined;

    @Json('productId')
    public productId: string = undefined;

    @Json('title')
    public title: string = undefined;

    @Json('message')
    public message: string = undefined;

    @Json('icon')
    public icon: string = undefined;

    @Json('image')
    public image: string = undefined;

    @Json('link')
    public link: string = undefined;

    constructor() {
        super();
        this.productId = '';
        this.type = '';
        this.validateRules = new ValidateModel();
        this.initValidateRules();
    }

    public initValidateRules(): ValidateModel {
        this.addRule('type', 'required', true, this._t('This field is required'));
        this.addRule('title', 'required', true, this._t('This field is required'));
        this.addRule('title', 'maxLength', INPUT_MAXLENGTH, this._t(`Maximum {0} characters.`, INPUT_MAXLENGTH));

        this.addRule('message', 'required', true, this._t('This field is required'));
        this.addRule('message', 'maxLength', INPUT_MAXLENGTH, this._t(`Maximum {0} characters.`, INPUT_MAXLENGTH));

        return this.getRules();
    }
}
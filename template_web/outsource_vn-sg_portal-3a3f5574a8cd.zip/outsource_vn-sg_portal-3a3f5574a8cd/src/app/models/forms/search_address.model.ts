import {BaseSearchModel} from './base_search.model';

export class SearchAddressModel extends BaseSearchModel {
    public user_id: string = '';
}

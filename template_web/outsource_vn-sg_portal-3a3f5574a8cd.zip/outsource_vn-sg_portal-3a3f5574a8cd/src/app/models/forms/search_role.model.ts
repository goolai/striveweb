/**
 * Created by thanhphan on 10/16/16.
 */
import { BaseSearchModel } from './base_search.model';

export class SearchRoleModel extends BaseSearchModel {
}

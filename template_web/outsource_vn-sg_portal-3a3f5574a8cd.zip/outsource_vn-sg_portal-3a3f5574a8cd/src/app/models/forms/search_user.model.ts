/**
 * Created by thanhphan on 10/16/16.
 */
import { BaseSearchModel } from './base_search.model';

export class SearchUserModel extends BaseSearchModel {
    public user_id: string = undefined;
    public phone_number: string = undefined;
    public referrals_by: string = undefined;
    public role_id: string = undefined;
    public is_vip: number = undefined;
    constructor() {
        super();
        this.phone_number = '';
        this.referrals_by = '';
    }
}

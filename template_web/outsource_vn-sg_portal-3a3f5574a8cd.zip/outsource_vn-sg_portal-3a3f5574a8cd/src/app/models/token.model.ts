import { UserModel } from './user.model';
import { BaseModel } from './base.model';
import { Json } from '../modules';

export class TokenModel extends BaseModel {
  @Json('token')
  public token: string = undefined;

  // @Json('firebaseToken')
  // public firebaseToken: string = undefined;

  @Json('expire')
  public expiredTime: string = undefined;

  @Json('userId')
  public userId: string = undefined;

  @Json({ name: 'user', clazz: UserModel, omitEmpty: true })
  public user: UserModel = undefined;
}

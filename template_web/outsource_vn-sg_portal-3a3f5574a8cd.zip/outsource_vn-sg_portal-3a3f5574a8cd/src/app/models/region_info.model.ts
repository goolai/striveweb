import { BaseModel } from './base.model';
import { ValidateModel } from './validate.model';
import { Json } from '../modules';

export class RegionInfoModel extends BaseModel {

  @Json('wardCode')
  public wardCode: string = undefined;

  @Json('districtCode')
  public districtCode: string = undefined;

  @Json('cityCode')
  public cityCode: string = undefined;

  constructor() {
    super();
    this.wardCode = '';
    this.districtCode = '';
    this.cityCode = '';
    this.validateRules = new ValidateModel();
    this.initValidateRules();
  }

  /**
   * init validate rule
   * @returns {ValidateModel}
   */
  public initValidateRules(): ValidateModel {
    // this.addRule('wardCode', 'required', true, this._t('This field is required'));
    this.addRule('districtCode', 'required', true, this._t('This field is required'));
    this.addRule('cityCode', 'required', true, this._t('This field is required'));

    return this.getRules();
  }
}
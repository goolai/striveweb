export const HTTP_METHOD = {
  GET: 'GET',
  POST: 'POST',
  PUT: 'PUT',
  DELETE: 'DELETE'
};

export const AUTHORIZATION = {
  TYPE: 'Authorization',
  METHOD: 'Bearer'
};

/**
 * Platform type.
 */
export const PLATFORM = {
  ANDROID: 'android',
  IOS: 'ios',
  WEB: 'web',
  PORTAL: 'portal',
  MOBILE: 'mobile'
};

export const PLATFORM_ARR = [
  PLATFORM.PORTAL,
  PLATFORM.WEB
  // PLATFORM.MOBILE,
  // PLATFORM.ANDROID,
  // PLATFORM.IOS,
];

export const SESSION = {
  FIREBASE_TOKEN_KEYWORD: 'firebase_token',
  TOKEN_KEYWORD: 'token',
  PROFILE_KEYWORD: 'profile',
  LANGUAGE_KEYWORD: 'language',
  NEXT_URL_KEYWORD: 'nextUrl',
  PREV_URL_KEYWORD: 'prevUrl'
};

export const ERROR_CODE = {
  AUTHENTICATION: {
    INVALID_AUTHORIZATION_HEADER: 1100,
    TOKEN_NOT_FOUND: 1101,
    TOKEN_INVALID: 1102,
    TOKEN_EXPIRE: 1103,
  }
};

export const PAGINATION = {
  MAX_SIZE: 7,
  ITEMS_PER_PAGE: 50,
  PAGE_ITEM_SIZE: [5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 100]
};

export const HEADERS = {
  TOTAL_ITEMS: 'Total',
  ITEM_PER_PAGE: 'Item-Per-Page',
  CONTENT_DISPOSITION: 'Content-Disposition',
  CONTENT_TYPE: 'Content-Type',
  STATUS_CODE_SUCCESS: 200,
  DEVIDE_OS: 'device-os',
  APP_VERSION: 'app-version',
  LANGUAGE: 'language',
};

export const HTTP = {
  METHOD: {
    GET: 'GET',
    POST: 'POST',
    PUT: 'PUT',
    DELETE: 'DELETE',
  },
  CONTENT_TYPE: {
    JSON: 'application/json; charset=utf-8'
  },
  HEADER: {
    DEVIDE_OS: 'webPortal',
    APP_VERSION: '1.0.0',
  }
};
export const REST_API = {
  SITE: {
    LOGIN: `accounts/auth/ctr_portal/login`,
    REGISTER: `accounts/auth/register`,
    FORGOT_PASSWORD: `accounts/auth/lost_password`,
    LOGOUT: `accounts/auth/logout`
  },
  USER: {
    LIST: `accounts/manage_users`,
    CREATE: `accounts/manage_users`,
    DELETE: `accounts/manage_users`,
    UPDATE: `accounts/manage_users`,
    DETAIL: `accounts/manage_users`
  },
  ME: {
    PROFILE: `accounts/auth/profile`,
    CHANGE_PASSWORD: `accounts/auth/update_password`,
    FIREBASE_TOKEN: `auth/firebase`
  },
  ROLE: {
    LIST: `roles`,
    CREATE: `roles`,
    DELETE: `roles`,
    UPDATE: `roles`,
    DETAIL: `roles`
  },
  MEDIA: `media/upload`,
  FILE: `media/files`,
  VARIABLE: {
    LIST: `settings/variable/ctr_manage`,
    DETAIL: `settings/ctr_info`,
    CREATE: `settings/variable/ctr_manage`,
    UPDATE: `settings/ctr_info`,
    DELETE: `settings/ctr_info`,
    LIST_BANNER: `settings/banner/ctr_manage`,
    DETAIL_BANNER: `settings/banner/ctr_info`,
    CREATE_BANNER: `settings/banner/ctr_manage`,
    UPDATE_BANNER: `settings/banner/ctr_info`,
    DELETE_BANNER: `settings/banner/ctr_info`,
    SYNC_DATA_AUTO_UPDATE_WAREHOUSE_CONFIRM_DATE: `settings/stock/auto_update/warehouse_confirm_date`,
  },
  ADDRESS: {
    LIST: `user_address/manage`,
    CREATE: `user_address/manage`,
    DELETE: `user_address/manage/ctr_info`,
    UPDATE: `user_address/manage/ctr_info`,
    UPDATE_DEFAULT: `user_address/manage/set_default`,
    DETAIL: `user_address/manage/ctr_info`
  },
  NOTIFICATIONS: {
    NOTIFICATION_MESSAGES_LIST: `notifications/f_admin/ctr_manage/push_messages/ads`,
    NOTIFICATION_MESSAGES_CREATE: `notifications/f_admin/ctr_manage/push_messages/ads`,
  }
};

export const HTTP_CONNNECTION_TIMEOUT = 300000; // 5 minutes
export const MAX_SIZE_UPLOAD = 10; // 10 MB
export const MAX_MEDIA_SIZE_UPLOAD = 50; // 50 MB
export const IMAGE_EXTENSION = 'jpg|jpeg|png|JPG|JPEG|PNG';
export const DOCUMENT_EXTENSION = 'pdf|PDF';
export const FILE_EXTENSION = 'csv';
export const ZIP_EXTENSION = 'zip';
export const MAX_TITLE = 255;
export const MAX_DESC = 2500;
export const MAX_LENGTH_PHONE = 11;
export const MAX_LENGTH_NUMBER = 255;
export const MAX_LENGTH_PASSWORD = 255;

/**
 * Method type define.
 */
export const METHOD_TYPE = {
  MANUAL: 'manual',
  AUTO: 'auto'
};

/**
 * Array method types are available.
 */
export const METHOD_TYPE_ARR = [
  METHOD_TYPE.MANUAL,
  METHOD_TYPE.AUTO,
];

export const MOMENT_DATE_FORMAT = {
  YYYY_MM_DD: 'YYYY-MM-DD',
  DD_MMM_YY: 'DD MMM YY',
  DD_MMM_YY_H_m: 'DD MMM YY HH:mm',
  MM_DD_YYYY: 'MM-DD-YYYY',
  DD_MM_YYYY: 'DD-MM-YYYY',
  YYYY_MM_DD_H_m: 'YYYY-MM-DD HH:mm',
  MM_DD_YYYY_H_m: 'MM-DD-YYYY HH:mm',
  DD_MM_YYYY_H_m: 'DD-MM-YYYY HH:mm',
  DD_MMMM_YYYY_hh_mm_A: 'DD MMMM YYYY, hh:mm A',
  HH_MM: 'HH:mm',
  h_mm_a: 'h:mm A',
  MM_YYYY: 'MMM-YYYY',
};

export const TIME_OUT_REDIRECT = 2000;
export const TIME_OUT_LOGOUT_FIREBASE = 5000;

export const ROLE = {
  SYSTEM_ADMIN: 'system_admin',             // All
  MANAGER: 'manager',                       // All
  ANONYMOUS: 'anonymous'
};

/**
 * Only allow privilege access system.
 */
export const APP_ROUTING_PRIVILEGES = [
  ROLE.SYSTEM_ADMIN, ROLE.MANAGER
];

/**
 * Define country available.
 */
export const COUNTRY_AVAILABLE = {
  VIETNAM: 'Vietnam',
  AUSTRALIA: 'Australia'
};

/**
 * Define country available.
 */
export const COUNTRY_AVAILABLE_ARR = [
  COUNTRY_AVAILABLE.VIETNAM,
  COUNTRY_AVAILABLE.AUSTRALIA
];

export const LANGUAGE = {
  ENGLISH: 'en',
  VIETNAM: 'vn',
};

export const MAX_PRODUCT_IMAGE = 6;
export const barcode = '';
export const LOGO_DEFAULT = 'assets/img/logos/logo-big-black.png';
export const AVATAR_DEFAULT = 'assets/img/icon/avatar_default.png';

/**
 * Define all variables default.
 */
export const DATA_DEFAULT = {
  DISCOUNT_SPECICAL_ON_SYSTEM: 0.05,          // Discount special for all orders on website or mobile apps.
};

/**
 * Export data asset.
 */
export const DATA_ASSET = {
  ICON_CHECK: 'assets/img/icon/icon_check_orange.png'
};

export const STATE_EVENT = {
  MENU_COLLAPSED: 'menu.isCollapsed',
  UPDATE_PROFILE: 'updateProfile',
  LOGOUT: 'logout'
};

export const SORT_TYPES = {
  ASC: 'asc',
  DESC: 'desc'
};

export const SPINNER_DELAY_TIME = 0;    // milisecond
export const INPUT_MAXLENGTH = 255;     // characters
export const INPUT_NUMBER_MAX_LENGTH = 20; // characters
export const CATEGORY_INPUT_MAXLENGTH = 100; // characters
export const PROGRSS_BAR_DEFAULT = 75;    // 75% default

export const hardCode = false; // hard code default value
export const COUNTRY_VIET_NAME = 'vn'; // 5 MB
export const TIME_TRIGGER_RESIZE_MAP = 500;

export const ENABLE_STATUS = {
  NO: false,
  YES: true
};

export const DELETE_STATUS = {
  NO: false,
  YES: true
};

export const ENABLE_STATUS_ARR = [
  ENABLE_STATUS.YES,
  ENABLE_STATUS.NO
];

export const IMAGE_ORIENTATION = {
  PORTRAIT: 'Portrait',
  LANDSCAPE: 'Landscape'
};

export const DATE_FORMAT = {
  YYYY_MM_DD: 'yyyy-MM-dd',
  DD_MM_YYYY: 'dd-MM-yyyy',
  DD_MM_YYYY_HH_MM: 'dd-MM-yyyy HH:mm',
  H_MM_A_DD_MM_YYYY: 'h:mm a dd-MM-yyyy',
};

export const MIN_AUTO_COMPLETE_FILTER_CHAR = 3;
export const DEPLAY_AUTO_COMPLETE_FILTER_CHAR = 200;

export const CKEDITOR_CONFIG = {
  height: 300,
  fullPage: true,
  allowedContent: true,
  removeButtons: 'Source,Save,Form,Radio,Templates,Find,Replace,Scayt,SelectAll,Preview,Maximize,About CKEditor'
};

export const VIEW_CKEDITOR_CONFIG = {
  height: 300,
  fullPage: false,
  allowedContent: false,
  removeButtons: 'Source,Save,Form,Radio,Templates,Find,Replace,Scayt,SelectAll,Preview,Maximize,About CKEditor'
};

export const TOASTR_SHORT_TIMEOUT = 1000;
export const TOASTR_TIMEOUT = 2000;

export const REDUX_ACTION = {
  LOGIN: 'login'
};

export const GENDER = [
  'n/a',
  'male',
  'female'
];

export const PROPERTIES_DEFAULT = {
  CODE: 'code',
  MESSAGE: 'message',
  ORDER_ITEMS: 'orderItems'
};

export const PAGE_LOAD_KEY = {
  CUR_PAGE: 'cur_page',
  PREVIOUS_PAGE: 'previous_page'
};

/**
 * Data type default.
 */
export const DATA_TYPE = {
  TEXT: 'text',
  NUMBER: 'number',
  HTML: 'html',
  JSON: 'json',
  BANNER: 'banner',
  TRAILER: 'trailer',
  POPUP_BANNER: 'popup_banner',
  PROMOTION_BANNER: 'promotion_banner',
  ADS_BANNER: 'ads_banner',
  DATA_TYPE_PERCENT: '%',
  DATA_TYPE_CURRENCY: '$'
};

/**
 * Define settings key.
 */
export const SETTINGS_KEY = {
  PRODUCT_SKU_PREFIX: 'product_sku_prefix',
  GUIDE_ORDER_ON_WEBSITE: 'guide_order_on_website',
  GUIDE_TRACK_ORDER_ON_WEBSITE: 'guide_track_order_on_website',
  SHIPPING_METHOD: 'shipping_method',
  GUIDE_RETURN_PACKAGE: 'guide_return_package',
  TERM_OF_USE: 'term_of_use',
  TERM_OF_CONDITION_POLICY: 'term_of_condition_policy',
  CAREER: 'career',
  ECOM_POLICY: 'ecom_policy',
  ABOUT_US: 'about_us'
};

/**
 * Define file type.
 */
export const FILE_TYPE = {
  MEDIA_FILE: 'media',   // Maybe is image or video.
  IMAGE: 'image',
  VIDEO: 'video',
  DOCUMENT: 'document',
  QR_CODE: 'qr_code',
  DATA: 'data',
};

/**
 * Defined push notification type.
 */
export const FCM_PUSH_TYPE = {
  MESSAGE: 'message',
  PRODUCT: 'product',     // Navigate to Product detail
  PROMOTION: 'promotion', // Navigate to Promotion
  LIVE: 'live',           // Navigate to Live
  WEB: 'web'              // Open browser and display url link
};

export const FCM_PUSH_TYPE_ARR = [
  FCM_PUSH_TYPE.MESSAGE,
  FCM_PUSH_TYPE.WEB,
  FCM_PUSH_TYPE.LIVE,
  FCM_PUSH_TYPE.PRODUCT
];

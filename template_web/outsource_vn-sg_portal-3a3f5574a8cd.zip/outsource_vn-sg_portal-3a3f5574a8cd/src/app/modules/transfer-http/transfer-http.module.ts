import { NgModule } from '@angular/core';
import { TransferHttp } from './transfer-http';
import { HttpClientModule } from '@angular/common/http';

@NgModule({
  imports: [
    HttpClientModule
  ],
  providers: [
    TransferHttp
  ]
})
export class TransferHttpModule { }

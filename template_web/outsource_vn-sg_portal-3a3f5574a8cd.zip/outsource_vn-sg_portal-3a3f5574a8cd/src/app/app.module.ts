import { AuthGuard } from './services';
import { AuthService } from './services';

import { NgModule, Inject, ApplicationRef, PLATFORM_ID } from '@angular/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { RouterModule, PreloadAllModules } from '@angular/router';

import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { AppRoutingModule } from './app-routing.module';
import { SharedModule } from './shared/shared.module';
import { ToastrModule } from 'ngx-toastr';
import { AgmCoreModule } from '@agm/core';
import { CacheModule } from '@ngx-cache/core';
import { HttpClientModule, HttpClient, HTTP_INTERCEPTORS } from '@angular/common/http';
import { TranslateModule, TranslateLoader, TranslateService } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { StoreModule } from '@ngrx/store';
import { ConfigModule, ConfigLoader, ConfigService, ConfigStaticLoader } from '@ngx-config/core';
import { MetaLoader, MetaModule, MetaStaticLoader } from '@ngx-meta/core';
import { DragulaService } from 'ng2-dragula';

import { routes } from './app.routing';
import { AppComponent } from './app.component';
import { ContentLayoutComponent } from './original/layouts/content/content-layout.component';
import { FullLayoutComponent } from './original/layouts/full/full-layout.component';
import { TransferHttpModule } from './modules/transfer-http/transfer-http.module';

import { configuration } from './config/configuration';
import { APP_PROVIDERS } from './app.providers';
import { AppInterceptor } from './app-interceptor';
import { PlatformHelper } from './helpers';

export function createTranslateLoader(http: HttpClient) {
    return new TranslateHttpLoader(http, './assets/i18n/', '.json');
}

export function configFactory(): ConfigLoader {
    return new ConfigStaticLoader(configuration);
}

export function metaFactory(config: ConfigService, translate: TranslateService): MetaLoader {
    return new MetaStaticLoader({
        callback: (key: string) => translate.get(key),
        pageTitlePositioning: config.getSettings('seo.pageTitlePositioning'),
        pageTitleSeparator: config.getSettings('seo.pageTitleSeparator'),
        applicationName: config.getSettings('system.applicationName'),
        applicationUrl: config.getSettings('system.applicationUrl'),

        defaults: {
            title: config.getSettings('seo.defaultPageTitle'),
            description: config.getSettings('seo.defaultMetaDescription'),
            generator: config.getSettings('seo.defaultPageTitle'),
            'twitter:title': config.getSettings('seo.defaultPageTitle'),
            'twitter:description': config.getSettings('seo.defaultMetaDescription'),
            'twitter:image': config.getSettings('seo.defaultMetaImage'),
            'twitter:card': 'summary',
            'og:title': config.getSettings('seo.defaultPageTitle'),
            'og:description': config.getSettings('seo.defaultMetaDescription'),
            'og:type': 'article',
            'og:image': config.getSettings('seo.defaultMetaImage'),
            'og:site_name': config.getSettings('system.applicationName'),
            'og:locale': config.getSettings('i18n.defaultLanguage.culture'),
            'og:locale:alternate': config.getSettings('i18n.availableLanguages')
                .map((language: any) => language.culture).toString(),
        }
    });
}

@NgModule({
    declarations: [
        AppComponent,
        FullLayoutComponent,
        ContentLayoutComponent
    ],
    imports: [
        BrowserAnimationsModule,
        StoreModule.forRoot({}),
        AppRoutingModule,
        SharedModule,
        HttpClientModule,
        ToastrModule.forRoot(),
        NgbModule.forRoot(),
        CacheModule.forRoot(),
        RouterModule.forRoot(routes, { useHash: true, preloadingStrategy: PreloadAllModules }),
        TranslateModule.forRoot({
            loader: {
                provide: TranslateLoader,
                useFactory: (createTranslateLoader),
                deps: [HttpClient]
            }
        }),
        AgmCoreModule.forRoot({
            apiKey: configuration.googleMap.apiKey
        }),
        ConfigModule.forRoot({
            provide: ConfigLoader,
            useFactory: (configFactory)
        }),
        TransferHttpModule,
        // NgxSpinnerModule,
        MetaModule.forRoot({
            provide: MetaLoader,
            useFactory: (metaFactory),
            deps: [ConfigService, TranslateService]
        })
    ],
    providers: [
        AuthService,
        AuthGuard,
        DragulaService,
        APP_PROVIDERS,
        {
            provide: HTTP_INTERCEPTORS,
            useClass: AppInterceptor,
            multi: true
        }
    ],
    bootstrap: [AppComponent]
})

export class AppModule {
    constructor(@Inject(PLATFORM_ID) private readonly platformId: any,
        public appRef: ApplicationRef) {
        // set platform id
        PlatformHelper.setPlatform(platformId);
    }
}
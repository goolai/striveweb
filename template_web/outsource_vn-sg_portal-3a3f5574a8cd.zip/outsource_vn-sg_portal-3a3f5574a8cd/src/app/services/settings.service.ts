import { RoleModel } from '../models/role.model';
import { JsonMapper } from '../modules/mapper/json.mapper';
import { TransferHttp } from '../modules/transfer-http/transfer-http';
import { UtilHelper } from '../helpers/util.helper';
import { Injectable } from '@angular/core';
import { PaginationModel, ResponseModel, SettingModel } from '../models';
import { REST_API } from '../modules/constants';
import { BaseService } from './base.service';

@Injectable()
export class SettingsService extends BaseService {

    constructor(public http: TransferHttp) {
        super(http);
    }

    /**
     * Get list variable
     * @returns {Promise<T>|Promise<U>}
     */
    public findAll(paging: boolean = true, filter: any = {}): Promise<PaginationModel> {

        if (!paging) {
            filter.offset = '';
            filter.limit = '';
        }
        const queryString = UtilHelper.parseFilterToString(filter);
        return this.makeHttpGet(`${this.apiUrl}/` + REST_API.VARIABLE.LIST + '?' + queryString)
            .then((res) => {
                res.data = JsonMapper.deserialize(SettingModel, res.data);
                return res;
            });
    }

    /**
     * Get variable detail.
     * @param id
     */
    public detail(id: string): Promise<SettingModel> {
        return this.makeHttpGet(`${this.apiUrl}/${REST_API.VARIABLE.DETAIL}/${id}`)
            .then((res) => {
                return JsonMapper.deserialize(SettingModel, res);
            });
    }

    /**
     * Create new variable
     * @param data
     */
    public create(data: SettingModel): Promise<ResponseModel> {
        return this.makeHttpPost(`${this.apiUrl}/` + REST_API.VARIABLE.CREATE, JsonMapper.serialize(data));
    }

    /**
     * Edit variable
     * @returns {Promise<T>|Promise<U>}
     */
    public update(data: SettingModel): Promise<ResponseModel> {
        return this.makeHttpPut(`${this.apiUrl}/` + REST_API.VARIABLE.UPDATE + '/' + data.id, JsonMapper.serialize(data));
    }

    /**
     * Delete item variable
     * @param data
     */
    public deleteItem(id: string): Promise<ResponseModel> {
        return this.makeHttpDelete(`${this.apiUrl}/` + REST_API.VARIABLE.DELETE + '/' + id);
    }
}

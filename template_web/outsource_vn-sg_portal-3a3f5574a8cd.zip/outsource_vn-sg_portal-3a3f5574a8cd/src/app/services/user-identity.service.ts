import { SESSION } from '../modules/constants';
import { UserModel, TokenModel } from '../models';
import { JsonMapper } from '../modules';
import { PlatformHelper } from 'app/helpers';

export class UserIdentityService {
  constructor() {
  }

  /**
   * Set token
   * @param data
   */
  public static setCredentials(data: TokenModel) {
    this.setToken(data && data.token ? data.token : null);
    this.setProfile(data && data.user ? data.user : null);
  }

  /**
   * Set User Profile
   * @param token
   */
  public static setToken(token: string = '') {
    if (PlatformHelper.isPlatformBrowser()) {
      if (token) {
        sessionStorage.setItem(SESSION.TOKEN_KEYWORD, token);
      } else {
        sessionStorage.removeItem(SESSION.TOKEN_KEYWORD);
      }
    }
  }

  /**
   * Set user profile
   * @param data
   */
  public static setProfile(data: UserModel) {
    if (data instanceof UserModel) {
      let obj = UserModel.toProfileModel(data);

      sessionStorage.setItem(SESSION.PROFILE_KEYWORD, JSON.stringify(obj));
    } else {
      sessionStorage.removeItem(SESSION.PROFILE_KEYWORD);
    }
  }

  /**
   * Get user profile from session.
   * @returns {any}
   */
  public static getProfile() {
    if (sessionStorage.length) {
      const profile = sessionStorage.getItem(SESSION.PROFILE_KEYWORD);
      if (profile) {
        return JSON.parse(profile);
      }
    }
    return {};
  }

  /**
   * Clear login data
   */
  public static clearCredentials() {
    if (PlatformHelper.isPlatformBrowser()) {
      sessionStorage.clear();
    }
  }

  /**
   * Check user logged or not logged
   * @returns {boolean}
   */
  public static isLoggedIn() {
    return this.getToken() ? true : false;
  }

  /**
   * Get token from session.
   * @returns {any}
   */
  public static getToken() {
    if (sessionStorage.length) {
      let token = sessionStorage.getItem(SESSION.TOKEN_KEYWORD);
      if (token) {
        return token;
      }
      return '';
    }
  }
}

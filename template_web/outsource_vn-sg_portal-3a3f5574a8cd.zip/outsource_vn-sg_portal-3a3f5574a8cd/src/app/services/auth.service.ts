import { JsonMapper } from '../modules';
import { TransferHttp } from '../modules/transfer-http/transfer-http';
import { Injectable } from '@angular/core';
import * as _ from 'lodash';

import { TokenModel, ResponseModel, UserModel } from '../models';
import { REST_API } from '../modules/constants';
import { BaseService } from './base.service';

@Injectable()
export class AuthService extends BaseService {

  constructor(protected _http: TransferHttp) {
    super(_http);
  }

  /**
   * Login
   */
  public login(data: UserModel): Promise<TokenModel> {
    const obj = JsonMapper.serialize(data);
    return this.makeHttpPost(`${this.apiUrl}/` + REST_API.SITE.LOGIN, obj)
      .then((res) => {
        return JsonMapper.deserialize(TokenModel, res);
      });
  }

  /**
   * Register
   */
  public register(data: UserModel): Promise<TokenModel> {
    const obj = JsonMapper.serialize(data);

    return this.makeHttpPost(`${this.apiUrl}/` + REST_API.SITE.REGISTER, obj)
      .then((res) => {
        return JsonMapper.deserialize(TokenModel, res);
      });
  }

  /**
   * forgot password
   */

  public forgotPassword(data): Promise<ResponseModel> {
    const obj = JsonMapper.serialize(data);

    return this.makeHttpPost(`${this.apiUrl}/` + REST_API.SITE.FORGOT_PASSWORD, obj);
  }

  /**
   * Logout
   */
  public logout(): Promise<ResponseModel> {
    return this.makeHttpPost(`${this.apiUrl}/` + REST_API.SITE.LOGOUT)
      .then((res) => {
        return JsonMapper.deserialize(ResponseModel, res);
      });
  }
}

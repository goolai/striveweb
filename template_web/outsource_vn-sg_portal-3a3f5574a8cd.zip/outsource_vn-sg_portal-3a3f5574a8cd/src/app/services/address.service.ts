import { JsonMapper } from '../modules/mapper/json.mapper';
import { TransferHttp } from '../modules/transfer-http/transfer-http';
import { UtilHelper } from '../helpers/util.helper';
import { Injectable } from '@angular/core';
import { BaseService } from './base.service';
import { PaginationModel, ResponseModel, AddressModel } from '../models';
import { REST_API } from '../modules/constants';

@Injectable()
export class AddressService extends BaseService {

  constructor(public http: TransferHttp) {
    super(http);
  }

  /**
   * Get list
   * @returns {Promise<T>|Promise<U>}
   */
  public findAll(paging: boolean = true, filter: any = {}): Promise<PaginationModel> {

    if (!paging) {
      filter.offset = '';
      filter.limit = '';
    }
    let queryString = UtilHelper.parseFilterToString(filter);
    return this.makeHttpGet(`${this.apiUrl}/` + REST_API.ADDRESS.LIST + '?' + queryString)
      .then((res) => {
        res.data = JsonMapper.deserialize(AddressModel, res.data);
        return res;
      });
  }

  /**
   * edit
   * @returns {Promise<T>|Promise<U>}
   */
  public update(data: AddressModel): Promise<ResponseModel> {
    return this.makeHttpPut(`${this.apiUrl}/` +  REST_API.ADDRESS.UPDATE + '/' + data.id, JsonMapper.serialize(data));
  }

  /**
   * edit
   * @returns {Promise<T>|Promise<U>}
   */
  public updateSetDefault(data: AddressModel): Promise<ResponseModel> {
    return this.makeHttpPut(`${this.apiUrl}/` +  REST_API.ADDRESS.UPDATE_DEFAULT + '/' + data.id, JsonMapper.serialize(data));
  }

  /**
   * delete
   * @returns {Promise<T>|Promise<U>}
   */
  public delete(id: string): Promise<ResponseModel> {
    return this.makeHttpDelete(`${this.apiUrl}/` + REST_API.ADDRESS.DELETE + '/' + id);
  }
  /**
   * create
   * @returns {Promise<T>|Promise<U>}
   */
  public create(data: AddressModel): Promise<ResponseModel> {
    return this.makeHttpPost(`${this.apiUrl}/` + REST_API.ADDRESS.CREATE , JsonMapper.serialize(data));
  }

  /**
   * Get detail
   * @returns {Promise<T>|Promise<U>}
   */
  public findById(id): Promise<AddressModel> {
    return this.makeHttpGet(`${this.apiUrl}/` +  REST_API.ADDRESS.DETAIL + '/' + id)
      .then((res) => {
        return JsonMapper.deserialize(AddressModel, res);
      });
  }
}
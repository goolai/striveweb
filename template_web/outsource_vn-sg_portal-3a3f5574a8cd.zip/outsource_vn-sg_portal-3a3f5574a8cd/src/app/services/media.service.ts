import { JsonMapper } from '../modules/mapper/json.mapper';
import { TransferHttp } from '../modules/transfer-http/transfer-http';
import { Injectable } from '@angular/core';

import { MediaModel } from '../models';
import { REST_API } from '../modules/constants';
import * as  _ from 'lodash';
import { BaseService } from './base.service';

@Injectable()
export class MediaService extends BaseService {

    constructor(protected _http: TransferHttp) {
        super(_http);
    }

    /**
     *
     * @param data
     * @returns {Promise<MediaModel>}
     */
    public uploadImage(data: MediaModel): Promise<MediaModel> {
        return this.uploadMedia(`${this.mediaUrl}/` + REST_API.MEDIA, data);
    }

    /**
     * Upload media file.
     * @param data
     */
    public uploadMediaFile(data: MediaModel): Promise<MediaModel> {
        return this.uploadMedia(`${this.mediaUrl}/` + REST_API.MEDIA, data);
    }

    /**
     * Update file.
     * @param data
     */
    public uploadFile(data: MediaModel): Promise<MediaModel> {
        return this.uploadMedia(`${this.apiUrl}/` + REST_API.FILE, data);
    }

    /**
     * Action push media file to server.
     * @param url
     * @param data
     */
    private uploadMedia(url: string, data: MediaModel): Promise<MediaModel> {
        const model = JsonMapper.serialize(data);
        const obj = this.toUploadFields(model);

        return this.makeHttpPost(url, obj)
            .then((res) => {
                return JsonMapper.deserialize(MediaModel, res);
            });
    }
}
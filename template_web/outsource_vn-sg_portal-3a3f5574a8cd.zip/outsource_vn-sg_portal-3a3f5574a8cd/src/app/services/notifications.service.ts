import { JsonMapper } from '../modules/mapper/json.mapper';
import { TransferHttp } from '../modules/transfer-http/transfer-http';
import { UtilHelper } from '../helpers/util.helper';
import { Injectable } from '@angular/core';
import { PaginationModel, ResponseModel, NotificationMessageModel } from '../models';
import { REST_API } from '../modules/constants';
import { BaseService } from './base.service';

@Injectable()
export class NotificationsService extends BaseService {

    constructor(public http: TransferHttp) {
        super(http);
    }

    /**
     * Get all notification messages
     * @param paging
     * @param filter
     */
    public findAllNotificationMessages(paging: boolean = true, filter: any = {}): Promise<PaginationModel> {
        if (!paging) {
            filter.offset = '';
            filter.limit = '';
        }

        const queryString = UtilHelper.parseFilterToString(filter);

        return this.makeHttpGet(`${this.apiUrl}/` + REST_API.NOTIFICATIONS.NOTIFICATION_MESSAGES_LIST + '?' + queryString)
            .then((res) => {
                res.data = JsonMapper.deserialize(NotificationMessageModel, res.data);
                return res;
            });
    }

    /**
     * Create new notification message and push to all mobile devices
     * @param data
     */
    public createNewPushMessage(data: NotificationMessageModel): Promise<ResponseModel> {
        return this.makeHttpPost(`${this.apiUrl}/` + REST_API.NOTIFICATIONS.NOTIFICATION_MESSAGES_CREATE, JsonMapper.serialize(data));
    }
}

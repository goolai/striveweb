import { JsonMapper } from '../modules';
import { UserIdentityService } from './user-identity.service';
import { ResponseModel } from '../models/response.model';
import { HTTP, ERROR_CODE, AUTHORIZATION, HTTP_METHOD, LANGUAGE, SESSION } from '../modules/constants';
import { PaginationModel } from '../models/pagination.model';
import { HEADERS } from '../modules/constants';
import { TransferHttp } from '../modules/transfer-http/transfer-http';
import { Injectable } from '@angular/core';
import * as _ from 'lodash';
import { UtilHelper, PlatformHelper } from '../helpers';
import { HttpHeaders, HttpResponse } from '@angular/common/http';
import { RequestOptions, ResponseContentType } from '@angular/http';
import * as fileSaver from 'file-saver';

@Injectable()
export class BaseService {
  public headers = new HttpHeaders();
  protected apiUrl: string;
  protected mediaUrl: string;

  constructor(public http: TransferHttp) {
    this.apiUrl = http.config.getSettings('rest.apiUrl');
    this.mediaUrl = http.config.getSettings('rest.mediaUrl');
  }

  /**
   * Set Header
   * @param key
   * @param value
   */
  public setHeader(key, value) {
    if (this.headers.has(key)) {
      this.headers = this.headers.set(key, value);
    } else {
      this.headers = this.headers.append(key, value);
    }
  }

  /**
   * Remove header.
   * @param header
   */
  public removeHeader(header) {
    this.headers = this.headers.delete(header);
  }

  /**
   * Get Header Options
   * @returns {RequestOptions}
   */
  private headerOptions(): any {
    let language: any = sessionStorage.getItem(SESSION.LANGUAGE_KEYWORD);
    let token = UserIdentityService.getToken();

    if (language) {
      language = JSON.parse(language);

      this.setHeader(HEADERS.LANGUAGE, language.code);
    } else {
      this.setHeader(HEADERS.LANGUAGE, LANGUAGE.VIETNAM);
    }

    if (token) {
      this.setHeader(AUTHORIZATION.TYPE, `${AUTHORIZATION.METHOD} ${token}`);
    }

    return { headers: this.headers };
  }

  /**
   * Parse Data From Server Reponse
   * @param res
   * @returns {any|{}}
   */
  public parseData(res: Response): Promise<any> {
    const headers = res.headers;
    let totalItems = 0;
    let itemsPerPage = 0;
    let ret: any;

    const contentType = headers.get(HEADERS.CONTENT_TYPE) ? headers.get(HEADERS.CONTENT_TYPE) : headers.get(HEADERS.CONTENT_TYPE.toLowerCase());

    if (contentType === HTTP.CONTENT_TYPE.JSON) {
      const obj: any = res.body;

      if (res.status === 200) {
        if (obj.status === false) {
          return Promise.reject(this.parseError(obj));
        }

        if (obj.status === true) {
          return Promise.resolve(this.parseInfo(obj));
        }

        if (_.isArray(obj)) {
          if (headers.has(HEADERS.TOTAL_ITEMS) || headers.has(HEADERS.TOTAL_ITEMS.toLowerCase())) {
            const total = headers.get(HEADERS.TOTAL_ITEMS) ? headers.get(HEADERS.TOTAL_ITEMS) : headers.get(HEADERS.TOTAL_ITEMS.toLowerCase());
            totalItems = total ? parseInt(total, 10) : 0;
          }

          if (headers.has(HEADERS.ITEM_PER_PAGE) || headers.has(HEADERS.ITEM_PER_PAGE.toLowerCase())) {
            itemsPerPage = parseInt(headers.get(HEADERS.ITEM_PER_PAGE), 10) ?
              parseInt(headers.get(HEADERS.ITEM_PER_PAGE), 10) : parseInt(headers.get(HEADERS.ITEM_PER_PAGE.toLowerCase()), 10);
          }

          ret = PaginationModel.toResponse(totalItems, itemsPerPage, obj);
        } else {
          if (headers.has(HEADERS.TOTAL_ITEMS) || headers.has(HEADERS.TOTAL_ITEMS.toLowerCase())) {
            const total = headers.get(HEADERS.TOTAL_ITEMS) ? headers.get(HEADERS.TOTAL_ITEMS) : headers.get(HEADERS.TOTAL_ITEMS.toLowerCase());

            totalItems = total ? parseInt(total, 10) : 0;

            ret = PaginationModel.toResponse(totalItems, itemsPerPage, obj);
          } else {
            ret = obj;
          }
        }
      }
    } else {
      ret = res.text();
    }

    return Promise.resolve(ret);
  }

  /**
   * Handle error.
   * @param error
   * @returns {ErrorObservable}
   */
  public handleError(error: any) {
    if (error.status === 0) {
      error = new Error(UtilHelper.translate('Could not connect to server, please try again in a few minutes'));
    } else if (error && error._body != null) {
      error = JSON.parse(error._body);
    }

    return Promise.reject(this.parseError(error));
  }

  /**
   * Parse error to model.
   * @param error
   */
  public parseError(data: any): ResponseModel {
    const error = JsonMapper.deserialize(ResponseModel, data);

    if (error && error.code) {
      switch (error.code) {
        case ERROR_CODE.AUTHENTICATION.INVALID_AUTHORIZATION_HEADER:
        case ERROR_CODE.AUTHENTICATION.TOKEN_EXPIRE:
        case ERROR_CODE.AUTHENTICATION.TOKEN_INVALID:
        case ERROR_CODE.AUTHENTICATION.TOKEN_NOT_FOUND:
          UserIdentityService.clearCredentials();

          if (PlatformHelper.isPlatformBrowser()) {
            window.location.href = '#/login';
          }
          break;

        default:
          break;
      }
    }

    return ResponseModel.init(error.code, error.message, undefined, error.title);
  }

  /**
   * Parse response to model object.
   * @param info
   */
  private parseInfo(data: any): ResponseModel {
    const info = JsonMapper.deserialize(ResponseModel, data);
    return ResponseModel.init(undefined, info.message, info.value, info.title);
  }

  /**
   * Make Http Get
   * @param url
   */
  public makeHttpGet(url: string): Promise<any> {
    return this.http.get(url, this.headerOptions())
      .then(this.parseData.bind(this))
      .catch(this.handleError.bind(this));
  }

  /**
   * Make Http Post
   * @param url
   * @param body
   */
  public makeHttpPost(url: string, body?: any): Promise<any> {
    return this.http.post(url, body, this.headerOptions())
      .then(this.parseData.bind(this))
      .catch(this.handleError.bind(this));
  }

  /**
   * Make Http Put
   * @param url
   * @param body
   */
  public makeHttpPut(url: string, body?: any): Promise<any> {
    return this.http.put(url, body, this.headerOptions())
      .then(this.parseData.bind(this))
      .catch(this.handleError.bind(this));
  }

  /**
   * Make Http Delete
   * @param url
   * @param body
   */
  public makeHttpDelete(url: string, body?: any): Promise<any> {
    return this.makeHttpRequest(HTTP_METHOD.DELETE, url, body);
  }

  /**
   * Make download file.
   * @param url
   */
  public makeHttpDownloadFile(url: string) {
    return this.http.downloadFile(url, this.headerOptions())
      .subscribe(resp => {
        window.location.href = resp.url;
      }, error => console.log('Error downloading the file'),
        () => {
          console.log('File downloaded successfully');
        });
  }

  /**
   * Method is use to download file.
   * @param data
   * @param type
   */
  protected openDownLoadFile(data: any, type: string) {
    let blob = new Blob([data], { type: type });
    let url = window.URL.createObjectURL(blob);
    let pwa = window.open(url);
    if (!pwa || pwa.closed || typeof pwa.closed === 'undefined') {
      alert('Please disable your Pop-up blocker and try again.');
    }
  }

  /**
   * Make Http Request
   * @param method
   * @param url
   * @param body
   */
  public makeHttpRequest(method: string, url: string, body: any): Promise<any> {
    const options = {
      headers: this.headers,
      body: body
    };

    return this.http.request(method, url, options)
      .then(this.parseData.bind(this))
      .catch(this.handleError.bind(this));
  }

  /**
   *
   * @param data
   * @returns {FormData}
   */
  protected toUploadFields(data: any = {}) {
    const formData = new FormData();
    _.forEach(data, (value, key) => {
      if (value instanceof FileList) {
        formData.append(key, value[0], value[0].name);
      } else {
        formData.append(key, value);
      }
    });

    return formData;
  }
}
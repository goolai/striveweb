import { JsonMapper } from '../modules/mapper/json.mapper';
import { ResponseModel, PaginationModel, UserModel, TokenModel } from '../models';
import { UtilHelper } from '../helpers/util.helper';
import { TransferHttp } from '../modules/transfer-http/transfer-http';
import { BaseService } from './base.service';
import { Injectable } from '@angular/core';
import { REST_API, ROLE } from '../modules/constants';

@Injectable()
export class UserService extends BaseService {
  constructor(public http: TransferHttp) {
    super(http);
  }


  /**
   * Logout Api
   */
  public logout(): Promise<string> {
    return this.makeHttpGet(`${this.apiUrl}/` + REST_API.SITE.LOGOUT);
  }
  /**
   * Get Profile
   */
  public profile(): Promise<UserModel> {
    return this.makeHttpGet(`${this.apiUrl}/` + REST_API.ME.PROFILE);
  }

  /**
   * Get list user
   * @returns {Promise<T>|Promise<U>}
   */
  public findAll(paging: boolean = true, filter: any = {}): Promise<PaginationModel> {

    if (!paging) {
      filter.offset = '';
      filter.limit = '';
    }

    const queryString = UtilHelper.parseFilterToString(filter);
    return this.makeHttpGet(`${this.apiUrl}/` + REST_API.USER.LIST + '?' + queryString)
      .then((res) => {

        res.data = JsonMapper.deserialize(UserModel, res.data);
        return res;
      });
  }

  /**
   * Get list user
   * @returns {Promise<T>|Promise<U>}
   */
  public findAllSupplier(paging: boolean = true, filter: any = {}): any {
    if (!paging) {
      filter.offset = '';
      filter.limit = '';
    }

    const queryString = UtilHelper.parseFilterToString(filter);
    return this.makeHttpGet(`${this.apiUrl}/` + REST_API.USER.LIST + '?' + queryString)
      .then((res) => {
        return JsonMapper.deserialize(UserModel, res.data);
      });
  }

  /**
   * Get user detail
   * @returns {Promise<T>|Promise<U>}
   */
  public findById(id, filter: any = {}): Promise<UserModel> {
    return this.makeHttpGet(`${this.apiUrl}/` + REST_API.USER.DETAIL + '/' + id)
      .then((res) => {
        return JsonMapper.deserialize(UserModel, res);
      });
  }

  /**
   * Get profile
   * @returns {Promise<TResult>}
   */
  public getProfile(): Promise<UserModel> {

    return this.makeHttpGet(`${this.apiUrl}/` + REST_API.ME.PROFILE)
      .then((res) => {
        return JsonMapper.deserialize(UserModel, res);
      });
  }

  /**
   * update user
   * @returns {Promise<T>|Promise<U>}
   */
  public updateProfile(data: UserModel): Promise<ResponseModel> {
    return this.makeHttpPut(`${this.apiUrl}/` + REST_API.ME.PROFILE, JsonMapper.serialize(data));
  }

  /**
   * update user
   * @returns {Promise<T>|Promise<U>}
   */
  public changePassword(data: UserModel): Promise<TokenModel> {
    let obj = JsonMapper.serialize(data);
    obj = UserModel.toChangePasswordResquest(obj);
    return this.makeHttpPut(`${this.apiUrl}/` + REST_API.ME.CHANGE_PASSWORD, obj)
      .then((res) => {
        return JsonMapper.deserialize(TokenModel, res);
      });
  }


  /**
   * create user
   * @returns {Promise<T>|Promise<U>}
   */
  public create(data: UserModel): Promise<ResponseModel> {
    return this.makeHttpPost(`${this.apiUrl}/` + REST_API.USER.CREATE, JsonMapper.serialize(data));
  }

  /**
   * edit user
   * @returns {Promise<T>|Promise<U>}
   */
  public update(data: UserModel): Promise<ResponseModel> {
    return this.makeHttpPut(`${this.apiUrl}/` + REST_API.USER.UPDATE + '/' + data.id, JsonMapper.serialize(data));
  }

  public updateAvatar(data: UserModel): Promise<ResponseModel> {
    const obj = JsonMapper.serialize(data);

    return this.makeHttpPut(`${this.apiUrl}/` + REST_API.USER.UPDATE + '/' + data.id, obj);
  }

  /**
   * delete user
   * @returns {Promise<T>|Promise<U>}
   */
  public delete(id: string): Promise<ResponseModel> {
    return this.makeHttpDelete(`${this.apiUrl}/` + REST_API.USER.DELETE + '/' + id);
  }
}

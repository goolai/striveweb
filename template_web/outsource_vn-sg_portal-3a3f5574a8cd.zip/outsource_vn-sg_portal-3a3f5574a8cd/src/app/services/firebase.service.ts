import { TransferHttp } from '../modules/transfer-http/transfer-http';
import { Injectable } from '@angular/core';
import { BaseService } from './base.service';

@Injectable()
export class AppFireBaseService extends BaseService {
    private user: any;
    private currentUser: any;
    constructor(
        protected _http: TransferHttp) {
        super(_http);
        this.user.subscribe((user) => {
            this.currentUser = user;
        });
    }

    // public loginByToken(token: string) {
    //     return this.afAuth.auth.signInWithCustomToken(token);
    // }

    // public logout() {
    //     this.afAuth.auth.signOut();
    // }
}

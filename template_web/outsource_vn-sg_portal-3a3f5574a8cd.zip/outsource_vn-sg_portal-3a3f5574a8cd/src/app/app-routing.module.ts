import { AuthGuard } from './services';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { FullLayoutComponent } from './original/layouts/full/full-layout.component';
import { ContentLayoutComponent } from './original/layouts/content/content-layout.component';

import { FULL_ROUTES } from './routes/full-layout.routes';
import { CONTENT_ROUTES } from './routes/content-layout.routes';
import { APP_ROUTING_PRIVILEGES } from './modules/constants';

const appRoutes: Routes = [
  {
    path: '',
    redirectTo: 'dasboard',
    pathMatch: 'full',
  },
  {
    path: '',
    component: FullLayoutComponent,
    data: {
      title: 'full Views', privileges: APP_ROUTING_PRIVILEGES
    },
    children: FULL_ROUTES,
    canActivate: [AuthGuard]
  },
  {
    path: '',
    component: ContentLayoutComponent,
    data: { title: 'content Views' },
    children: CONTENT_ROUTES
  }
];

@NgModule({
  imports: [RouterModule.forRoot(appRoutes)],
  exports: [RouterModule]
}) export class AppRoutingModule { }

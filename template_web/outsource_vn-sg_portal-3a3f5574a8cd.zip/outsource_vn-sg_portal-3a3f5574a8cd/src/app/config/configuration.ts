export const configuration = {
    rest: {
        apiUrl: 'https://api.strivefit.app',
        mediaUrl: 'https://api.strivefit.app'
    },
    system: {
        applicationName: 'Portal',
        applicationUrl: ''
    },
    seo: {
        defaultPageTitle: 'Strive Gym',
        pageTitlePositioning: 10,
        pageTitleSeparator: ' | ',
        defaultMetaDescription: 'Strive Gym',
        defaultMetaKeyword: 'Strive Gym',
        defaultMetaImage: ''
    },
    i18n: {
        defaultLanguage: {
            code: 'vn',
            name: 'Vietnamese',
            culture: 'vi-VN',
            img: 'assets/img/flags/vn.png'
        },
        availableLanguages: [
            {
                code: 'en',
                name: 'English',
                culture: 'en-US',
                img: 'assets/img/flags/us.png'
            },
            {
                code: 'vn',
                name: 'Vietnamese',
                culture: 'vi-VN',
                img: 'assets/img/flags/vn.png'
            }
        ],
        autoDetectLanguage: true,
        useLocalizedRoutes: true
    },
    social: {
        facebookAppId: 'fbid'
    },
    googleMap: {
        apiKey: 'key',
        latitude: 15.6073814,
        longitude: 101.344367,
        zoom: 5
    },
    firebase: {
        apiKey: 'firebase_api_key',
        authDomain: 'auth_domain_name',
        databaseURL: 'db_url',
        projectId: 'project_id',
        storageBucket: 'bucket_name',
        messagingSenderId: 'sender_id'
    }
};

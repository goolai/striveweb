import { Routes, RouterModule } from '@angular/router';
// Route for content layout with sidebar, navbar and footer.

export const FULL_ROUTES: Routes = [
  {
    path: 'dashboard',
    loadChildren: './components/dashboard/dashboard.module#DashboardModule'
  },
  {
    path: 'users',
    loadChildren: './components/users/users.module#UsersModule'
  },
  {
    path: 'profile',
    loadChildren: './components/profile/profile.module#ProfileModule'
  },
  {
    path: 'settings',
    loadChildren: './components/settings/settings.module#SettingsModule'
  },
  {
    path: 'notification_messages',
    loadChildren: './components/notification_messages/notification_messages.module#NotificationMessagesModule'
  },
  {
    path: 'page_not_found',
    loadChildren: './components/page_not_found/page_not_found.module#PageNotFoundModule'
  },
];
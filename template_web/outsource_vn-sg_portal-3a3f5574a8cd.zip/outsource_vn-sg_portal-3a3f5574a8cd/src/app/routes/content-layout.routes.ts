import { Routes, RouterModule } from '@angular/router';

// Route for content layout without sidebar, navbar and footer for pages like Login, Registration etc...
export const CONTENT_ROUTES: Routes = [
    {
        path: 'login',
        loadChildren: './components/auth/login/login.module#LoginModule'
    },
    {
        path: 'forgot_password',
        loadChildren: './components/auth/forgot_password/forgot-password.module#ForgotPasswordModule'
    }
];
